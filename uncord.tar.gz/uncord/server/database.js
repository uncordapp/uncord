const Database = require('better-sqlite3');
const path = require('path');
const fs = require('fs');

const DB_PATH = path.join(__dirname, '../data/uncord.db');
const DATA_DIR = path.join(__dirname, '../data');

if (!fs.existsSync(DATA_DIR)) fs.mkdirSync(DATA_DIR, { recursive: true });

const db = new Database(DB_PATH);

db.pragma('journal_mode = WAL');
db.pragma('foreign_keys = ON');
db.pragma('synchronous = NORMAL');

db.exec(`
  CREATE TABLE IF NOT EXISTS settings (
    key TEXT PRIMARY KEY,
    value TEXT NOT NULL
  );

  CREATE TABLE IF NOT EXISTS users (
    id TEXT PRIMARY KEY,
    username TEXT UNIQUE NOT NULL,
    discriminator TEXT NOT NULL DEFAULT '0000',
    email TEXT UNIQUE NOT NULL,
    password TEXT NOT NULL,
    avatar TEXT,
    banner TEXT,
    bio TEXT DEFAULT '',
    status TEXT DEFAULT 'online',
    custom_status TEXT DEFAULT '',
    role TEXT DEFAULT 'user',
    account_standing TEXT DEFAULT 'good',
    nitro INTEGER DEFAULT 1,
    badges TEXT DEFAULT '[]',
    accent_color TEXT DEFAULT '#5865F2',
    pronouns TEXT DEFAULT '',
    created_at INTEGER DEFAULT (unixepoch()),
    last_seen INTEGER DEFAULT (unixepoch()),
    banned INTEGER DEFAULT 0,
    ban_reason TEXT DEFAULT ''
  );

  CREATE TABLE IF NOT EXISTS servers (
    id TEXT PRIMARY KEY,
    name TEXT NOT NULL,
    description TEXT DEFAULT '',
    icon TEXT,
    banner TEXT,
    owner_id TEXT NOT NULL,
    server_tag TEXT DEFAULT '',
    community INTEGER DEFAULT 0,
    verified INTEGER DEFAULT 0,
    partnered INTEGER DEFAULT 0,
    boosts INTEGER DEFAULT 999,
    boost_level INTEGER DEFAULT 3,
    features TEXT DEFAULT '[]',
    invite_code TEXT UNIQUE,
    created_at INTEGER DEFAULT (unixepoch()),
    FOREIGN KEY (owner_id) REFERENCES users(id) ON DELETE CASCADE
  );

  CREATE TABLE IF NOT EXISTS channels (
    id TEXT PRIMARY KEY,
    server_id TEXT NOT NULL,
    name TEXT NOT NULL,
    type TEXT DEFAULT 'text',
    topic TEXT DEFAULT '',
    position INTEGER DEFAULT 0,
    category_id TEXT,
    nsfw INTEGER DEFAULT 0,
    slowmode INTEGER DEFAULT 0,
    created_at INTEGER DEFAULT (unixepoch()),
    FOREIGN KEY (server_id) REFERENCES servers(id) ON DELETE CASCADE
  );

  CREATE TABLE IF NOT EXISTS categories (
    id TEXT PRIMARY KEY,
    server_id TEXT NOT NULL,
    name TEXT NOT NULL,
    position INTEGER DEFAULT 0,
    FOREIGN KEY (server_id) REFERENCES servers(id) ON DELETE CASCADE
  );

  CREATE TABLE IF NOT EXISTS messages (
    id TEXT PRIMARY KEY,
    channel_id TEXT NOT NULL,
    author_id TEXT NOT NULL,
    content TEXT NOT NULL,
    type TEXT DEFAULT 'default',
    pinned INTEGER DEFAULT 0,
    edited_at INTEGER,
    attachments TEXT DEFAULT '[]',
    embeds TEXT DEFAULT '[]',
    reactions TEXT DEFAULT '{}',
    created_at INTEGER DEFAULT (unixepoch()),
    FOREIGN KEY (channel_id) REFERENCES channels(id) ON DELETE CASCADE,
    FOREIGN KEY (author_id) REFERENCES users(id) ON DELETE SET NULL
  );

  CREATE TABLE IF NOT EXISTS server_members (
    user_id TEXT NOT NULL,
    server_id TEXT NOT NULL,
    nickname TEXT DEFAULT '',
    roles TEXT DEFAULT '[]',
    joined_at INTEGER DEFAULT (unixepoch()),
    PRIMARY KEY (user_id, server_id),
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (server_id) REFERENCES servers(id) ON DELETE CASCADE
  );

  CREATE TABLE IF NOT EXISTS roles (
    id TEXT PRIMARY KEY,
    server_id TEXT NOT NULL,
    name TEXT NOT NULL,
    color TEXT DEFAULT '#99AAB5',
    permissions TEXT DEFAULT '[]',
    position INTEGER DEFAULT 0,
    mentionable INTEGER DEFAULT 1,
    hoist INTEGER DEFAULT 0,
    FOREIGN KEY (server_id) REFERENCES servers(id) ON DELETE CASCADE
  );

  CREATE TABLE IF NOT EXISTS direct_messages (
    id TEXT PRIMARY KEY,
    participants TEXT NOT NULL,
    created_at INTEGER DEFAULT (unixepoch())
  );

  CREATE TABLE IF NOT EXISTS dm_messages (
    id TEXT PRIMARY KEY,
    dm_id TEXT NOT NULL,
    author_id TEXT NOT NULL,
    content TEXT NOT NULL,
    edited_at INTEGER,
    attachments TEXT DEFAULT '[]',
    reactions TEXT DEFAULT '{}',
    created_at INTEGER DEFAULT (unixepoch()),
    FOREIGN KEY (dm_id) REFERENCES direct_messages(id) ON DELETE CASCADE
  );

  CREATE TABLE IF NOT EXISTS friends (
    user_id TEXT NOT NULL,
    friend_id TEXT NOT NULL,
    status TEXT DEFAULT 'pending',
    created_at INTEGER DEFAULT (unixepoch()),
    PRIMARY KEY (user_id, friend_id)
  );

  CREATE TABLE IF NOT EXISTS shop_items (
    id TEXT PRIMARY KEY,
    name TEXT NOT NULL,
    description TEXT DEFAULT '',
    type TEXT NOT NULL,
    data TEXT DEFAULT '{}',
    price INTEGER DEFAULT 0
  );

  CREATE TABLE IF NOT EXISTS user_inventory (
    user_id TEXT NOT NULL,
    item_id TEXT NOT NULL,
    acquired_at INTEGER DEFAULT (unixepoch()),
    PRIMARY KEY (user_id, item_id)
  );

  CREATE TABLE IF NOT EXISTS audit_log (
    id TEXT PRIMARY KEY,
    admin_id TEXT NOT NULL,
    action TEXT NOT NULL,
    target_type TEXT,
    target_id TEXT,
    details TEXT DEFAULT '{}',
    created_at INTEGER DEFAULT (unixepoch())
  );

  CREATE INDEX IF NOT EXISTS idx_messages_channel ON messages(channel_id, created_at DESC);
  CREATE INDEX IF NOT EXISTS idx_members_server ON server_members(server_id);
  CREATE INDEX IF NOT EXISTS idx_members_user ON server_members(user_id);
  CREATE INDEX IF NOT EXISTS idx_channels_server ON channels(server_id);
`);

// Seed default settings
const seedSettings = db.prepare(`INSERT OR IGNORE INTO settings (key, value) VALUES (?, ?)`);
seedSettings.run('platform_name', 'UnCord');
seedSettings.run('platform_description', 'Your self-hosted community platform');
seedSettings.run('allow_registration', 'true');
seedSettings.run('default_avatar_color', '#5865F2');
seedSettings.run('max_servers_per_user', '100');
seedSettings.run('max_message_length', '4000');
seedSettings.run('official_account_id', '');

module.exports = db;
