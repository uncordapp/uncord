const jwt = require('jsonwebtoken');
const db = require('../database');
const { JWT_SECRET } = require('../middleware/auth');

const connectedUsers = new Map(); // userId -> Set of socketIds

module.exports = function setupSocket(io) {
  io.use((socket, next) => {
    const token = socket.handshake.auth?.token;
    if (!token) return next(new Error('No token'));
    try {
      const decoded = jwt.verify(token, JWT_SECRET);
      const user = db.prepare('SELECT * FROM users WHERE id = ? AND banned = 0').get(decoded.id);
      if (!user) return next(new Error('Invalid user'));
      socket.user = user;
      next();
    } catch {
      next(new Error('Invalid token'));
    }
  });

  io.on('connection', (socket) => {
    const userId = socket.user.id;

    // Track connected users
    if (!connectedUsers.has(userId)) connectedUsers.set(userId, new Set());
    connectedUsers.get(userId).add(socket.id);

    // Update status to online
    db.prepare("UPDATE users SET status = 'online', last_seen = unixepoch() WHERE id = ?").run(userId);
    io.emit('user:status', { userId, status: 'online' });

    // Join all server rooms the user belongs to
    const memberships = db.prepare('SELECT server_id FROM server_members WHERE user_id = ?').all(userId);
    for (const { server_id } of memberships) {
      socket.join(`server:${server_id}`);
    }
    socket.join(`user:${userId}`);

    // ── Messages ──────────────────────────────────────────
    socket.on('message:send', ({ channel_id, content, attachments = [] }) => {
      const { v4: uuidv4 } = require('uuid');
      const channel = db.prepare('SELECT * FROM channels WHERE id = ?').get(channel_id);
      if (!channel) return;
      const member = db.prepare('SELECT * FROM server_members WHERE user_id = ? AND server_id = ?').get(userId, channel.server_id);
      if (!member) return;

      const maxLen = parseInt(db.prepare("SELECT value FROM settings WHERE key='max_message_length'").get()?.value || '4000');
      if (!content?.trim() || content.length > maxLen) return;

      const id = uuidv4();
      db.prepare('INSERT INTO messages (id, channel_id, author_id, content, attachments) VALUES (?, ?, ?, ?, ?)')
        .run(id, channel_id, userId, content, JSON.stringify(attachments));

      const msg = db.prepare('SELECT * FROM messages WHERE id = ?').get(id);
      msg.attachments = JSON.parse(msg.attachments || '[]');
      msg.embeds = [];
      msg.reactions = {};
      const author = db.prepare('SELECT id, username, discriminator, avatar, badges, role FROM users WHERE id = ?').get(userId);
      if (author) author.badges = JSON.parse(author.badges || '[]');
      msg.author = author;

      io.to(`server:${channel.server_id}`).emit('message:new', msg);
    });

    socket.on('message:edit', ({ message_id, content }) => {
      const msg = db.prepare('SELECT * FROM messages WHERE id = ?').get(message_id);
      if (!msg || (msg.author_id !== userId && socket.user.role !== 'admin')) return;
      db.prepare('UPDATE messages SET content = ?, edited_at = unixepoch() WHERE id = ?').run(content, message_id);
      const channel = db.prepare('SELECT * FROM channels WHERE id = ?').get(msg.channel_id);
      io.to(`server:${channel.server_id}`).emit('message:update', { message_id, content, edited_at: Math.floor(Date.now() / 1000) });
    });

    socket.on('message:delete', ({ message_id }) => {
      const msg = db.prepare('SELECT * FROM messages WHERE id = ?').get(message_id);
      if (!msg) return;
      const channel = db.prepare('SELECT * FROM channels WHERE id = ?').get(msg.channel_id);
      const server = db.prepare('SELECT * FROM servers WHERE id = ?').get(channel?.server_id);
      const canDelete = msg.author_id === userId || socket.user.role === 'admin' || server?.owner_id === userId;
      if (!canDelete) return;
      db.prepare('DELETE FROM messages WHERE id = ?').run(message_id);
      io.to(`server:${channel.server_id}`).emit('message:delete', { message_id, channel_id: msg.channel_id });
    });

    socket.on('message:react', ({ message_id, emoji }) => {
      const msg = db.prepare('SELECT * FROM messages WHERE id = ?').get(message_id);
      if (!msg) return;
      const reactions = JSON.parse(msg.reactions || '{}');
      if (!reactions[emoji]) reactions[emoji] = [];
      const idx = reactions[emoji].indexOf(userId);
      if (idx === -1) reactions[emoji].push(userId);
      else reactions[emoji].splice(idx, 1);
      if (reactions[emoji].length === 0) delete reactions[emoji];
      db.prepare('UPDATE messages SET reactions = ? WHERE id = ?').run(JSON.stringify(reactions), message_id);
      const channel = db.prepare('SELECT * FROM channels WHERE id = ?').get(msg.channel_id);
      io.to(`server:${channel.server_id}`).emit('message:reaction', { message_id, reactions });
    });

    // ── Typing ────────────────────────────────────────────
    socket.on('typing:start', ({ channel_id }) => {
      const channel = db.prepare('SELECT * FROM channels WHERE id = ?').get(channel_id);
      if (!channel) return;
      socket.to(`server:${channel.server_id}`).emit('typing:start', {
        channel_id, user: { id: userId, username: socket.user.username }
      });
    });

    socket.on('typing:stop', ({ channel_id }) => {
      const channel = db.prepare('SELECT * FROM channels WHERE id = ?').get(channel_id);
      if (!channel) return;
      socket.to(`server:${channel.server_id}`).emit('typing:stop', { channel_id, userId });
    });

    // ── DMs ───────────────────────────────────────────────
    socket.on('dm:send', ({ to_user_id, content }) => {
      const { v4: uuidv4 } = require('uuid');
      if (!content?.trim() || !to_user_id) return;

      const participants = [userId, to_user_id].sort().join(',');
      let dm = db.prepare('SELECT * FROM direct_messages WHERE participants = ?').get(participants);
      if (!dm) {
        const dmId = uuidv4();
        db.prepare('INSERT INTO direct_messages (id, participants) VALUES (?, ?)').run(dmId, participants);
        dm = db.prepare('SELECT * FROM direct_messages WHERE id = ?').get(dmId);
      }

      const id = uuidv4();
      db.prepare('INSERT INTO dm_messages (id, dm_id, author_id, content) VALUES (?, ?, ?, ?)').run(id, dm.id, userId, content);
      const msg = db.prepare('SELECT * FROM dm_messages WHERE id = ?').get(id);
      msg.reactions = {};
      msg.attachments = [];
      const author = db.prepare('SELECT id, username, discriminator, avatar, badges FROM users WHERE id = ?').get(userId);
      if (author) author.badges = JSON.parse(author.badges || '[]');
      msg.author = author;

      socket.emit('dm:message', { to_user_id, message: msg });
      io.to(`user:${to_user_id}`).emit('dm:message', { from_user_id: userId, message: msg });
    });

    // ── Server Events ─────────────────────────────────────
    socket.on('server:join', ({ server_id }) => {
      socket.join(`server:${server_id}`);
    });

    socket.on('server:leave', ({ server_id }) => {
      socket.leave(`server:${server_id}`);
    });

    // ── Voice ─────────────────────────────────────────────
    socket.on('voice:join', ({ channel_id }) => {
      const channel = db.prepare('SELECT * FROM channels WHERE id = ?').get(channel_id);
      if (!channel || channel.type !== 'voice') return;
      socket.join(`voice:${channel_id}`);
      io.to(`server:${channel.server_id}`).emit('voice:user_joined', { channel_id, userId, username: socket.user.username });
    });

    socket.on('voice:leave', ({ channel_id }) => {
      const channel = db.prepare('SELECT * FROM channels WHERE id = ?').get(channel_id);
      socket.leave(`voice:${channel_id}`);
      if (channel) io.to(`server:${channel.server_id}`).emit('voice:user_left', { channel_id, userId });
    });

    // ── Status ────────────────────────────────────────────
    socket.on('status:update', ({ status, custom_status }) => {
      const allowed = ['online', 'idle', 'dnd', 'invisible'];
      if (!allowed.includes(status)) return;
      db.prepare('UPDATE users SET status = ?, custom_status = ?, last_seen = unixepoch() WHERE id = ?').run(status, custom_status || '', userId);
      io.emit('user:status', { userId, status, custom_status });
    });

    // ── Disconnect ────────────────────────────────────────
    socket.on('disconnect', () => {
      const sockets = connectedUsers.get(userId);
      if (sockets) {
        sockets.delete(socket.id);
        if (sockets.size === 0) {
          connectedUsers.delete(userId);
          db.prepare("UPDATE users SET status = 'offline', last_seen = unixepoch() WHERE id = ?").run(userId);
          io.emit('user:status', { userId, status: 'offline' });
        }
      }
    });
  });

  // Expose helper for admin to broadcast
  return {
    broadcast: (event, data) => io.emit(event, data),
    toServer: (serverId, event, data) => io.to(`server:${serverId}`).emit(event, data),
    toUser: (userId, event, data) => io.to(`user:${userId}`).emit(event, data),
  };
};
