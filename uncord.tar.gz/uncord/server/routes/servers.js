const express = require('express');
const { v4: uuidv4 } = require('uuid');
const { auth } = require('../middleware/auth');
const db = require('../database');
const router = express.Router();

const ALL_FEATURES = ['COMMUNITY','NEWS','DISCOVERABLE','VERIFIED','PARTNERED','VANITY_URL',
  'INVITE_SPLASH','BANNER','ANIMATED_ICON','MEMBER_PROFILES','ROLE_ICONS','ANIMATED_BANNER',
  'AUTO_MODERATION','TICKETED_EVENTS_ENABLED','MONETIZATION_ENABLED','MORE_STICKERS',
  'PREMIUM_TIER_3_OVERRIDE','THREADS_ENABLED','THREE_DAY_THREAD_ARCHIVE',
  'SEVEN_DAY_THREAD_ARCHIVE','PRIVATE_THREADS','ROLE_SUBSCRIPTIONS_ENABLED'];

function generateInvite() {
  const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
  return Array.from({ length: 8 }, () => chars[Math.floor(Math.random() * chars.length)]).join('');
}

function formatServer(server) {
  if (!server) return null;
  server.features = JSON.parse(server.features || '[]');
  return server;
}

// Get all servers for current user
router.get('/me', auth, (req, res) => {
  const servers = db.prepare(`
    SELECT s.* FROM servers s
    JOIN server_members sm ON sm.server_id = s.id
    WHERE sm.user_id = ?
    ORDER BY sm.joined_at ASC
  `).all(req.user.id);
  res.json(servers.map(formatServer));
});

// Create server
router.post('/', auth, (req, res) => {
  const { name, icon } = req.body;
  if (!name) return res.status(400).json({ error: 'Server name required' });

  const id = uuidv4();
  const invite = generateInvite();

  db.prepare(`INSERT INTO servers (id, name, icon, owner_id, invite_code, boosts, boost_level, features)
    VALUES (?, ?, ?, ?, ?, 999, 3, ?)`).run(id, name, icon || null, req.user.id, invite, JSON.stringify(ALL_FEATURES));

  // Create default category and channels
  const catId = uuidv4();
  const genId = uuidv4();
  const vcId = uuidv4();

  db.prepare('INSERT INTO categories (id, server_id, name, position) VALUES (?, ?, ?, ?)').run(catId, id, 'General', 0);
  db.prepare('INSERT INTO channels (id, server_id, name, type, position, category_id) VALUES (?, ?, ?, ?, ?, ?)').run(genId, id, 'general', 'text', 0, catId);
  db.prepare('INSERT INTO channels (id, server_id, name, type, position, category_id) VALUES (?, ?, ?, ?, ?, ?)').run(vcId, id, 'General', 'voice', 1, catId);

  // Add owner as member
  db.prepare('INSERT INTO server_members (user_id, server_id, roles) VALUES (?, ?, ?)').run(req.user.id, id, '["owner"]');

  const server = db.prepare('SELECT * FROM servers WHERE id = ?').get(id);
  res.json(formatServer(server));
});

// Get server
router.get('/:id', auth, (req, res) => {
  const member = db.prepare('SELECT * FROM server_members WHERE user_id = ? AND server_id = ?').get(req.user.id, req.params.id);
  if (!member) return res.status(403).json({ error: 'Not a member' });

  const server = db.prepare('SELECT * FROM servers WHERE id = ?').get(req.params.id);
  if (!server) return res.status(404).json({ error: 'Server not found' });

  const channels = db.prepare('SELECT * FROM channels WHERE server_id = ? ORDER BY position ASC').all(req.params.id);
  const categories = db.prepare('SELECT * FROM categories WHERE server_id = ? ORDER BY position ASC').all(req.params.id);
  const members = db.prepare(`
    SELECT u.id, u.username, u.discriminator, u.avatar, u.status, u.custom_status, u.badges, u.role as platform_role,
           sm.nickname, sm.roles, sm.joined_at
    FROM users u JOIN server_members sm ON sm.user_id = u.id
    WHERE sm.server_id = ?
  `).all(req.params.id);

  res.json({
    ...formatServer(server),
    channels,
    categories,
    members: members.map(m => ({ ...m, badges: JSON.parse(m.badges || '[]'), roles: JSON.parse(m.roles || '[]') }))
  });
});

// Update server
router.patch('/:id', auth, (req, res) => {
  const server = db.prepare('SELECT * FROM servers WHERE id = ?').get(req.params.id);
  if (!server) return res.status(404).json({ error: 'Not found' });
  if (server.owner_id !== req.user.id && req.user.role !== 'admin') return res.status(403).json({ error: 'Forbidden' });

  const allowed = ['name', 'description', 'icon', 'banner', 'server_tag', 'community'];
  const updates = {};
  for (const key of allowed) {
    if (req.body[key] !== undefined) updates[key] = req.body[key];
  }

  if (updates.community !== undefined) {
    updates.boost_level = 3;
    updates.boosts = 999;
    updates.features = JSON.stringify(ALL_FEATURES);
  }

  if (Object.keys(updates).length) {
    const sets = Object.keys(updates).map(k => `${k} = ?`).join(', ');
    db.prepare(`UPDATE servers SET ${sets} WHERE id = ?`).run(...Object.values(updates), req.params.id);
  }

  res.json(formatServer(db.prepare('SELECT * FROM servers WHERE id = ?').get(req.params.id)));
});

// Join via invite
router.post('/join/:code', auth, (req, res) => {
  const server = db.prepare('SELECT * FROM servers WHERE invite_code = ?').get(req.params.code);
  if (!server) return res.status(404).json({ error: 'Invalid invite' });

  const existing = db.prepare('SELECT * FROM server_members WHERE user_id = ? AND server_id = ?').get(req.user.id, server.id);
  if (existing) return res.status(409).json({ error: 'Already a member' });

  db.prepare('INSERT INTO server_members (user_id, server_id) VALUES (?, ?)').run(req.user.id, server.id);
  res.json(formatServer(server));
});

// Leave server
router.delete('/:id/leave', auth, (req, res) => {
  const server = db.prepare('SELECT * FROM servers WHERE id = ?').get(req.params.id);
  if (server?.owner_id === req.user.id) return res.status(400).json({ error: 'Owner cannot leave' });
  db.prepare('DELETE FROM server_members WHERE user_id = ? AND server_id = ?').run(req.user.id, req.params.id);
  res.json({ success: true });
});

// Create channel
router.post('/:id/channels', auth, (req, res) => {
  const server = db.prepare('SELECT * FROM servers WHERE id = ?').get(req.params.id);
  if (!server) return res.status(404).json({ error: 'Not found' });
  if (server.owner_id !== req.user.id && req.user.role !== 'admin') return res.status(403).json({ error: 'Forbidden' });

  const { name, type, category_id, topic, nsfw } = req.body;
  if (!name) return res.status(400).json({ error: 'Name required' });

  const channelId = uuidv4();
  const pos = db.prepare('SELECT COUNT(*) as c FROM channels WHERE server_id = ?').get(req.params.id).c;

  db.prepare('INSERT INTO channels (id, server_id, name, type, position, category_id, topic, nsfw) VALUES (?, ?, ?, ?, ?, ?, ?, ?)')
    .run(channelId, req.params.id, name, type || 'text', pos, category_id || null, topic || '', nsfw ? 1 : 0);

  res.json(db.prepare('SELECT * FROM channels WHERE id = ?').get(channelId));
});

// Create category
router.post('/:id/categories', auth, (req, res) => {
  const server = db.prepare('SELECT * FROM servers WHERE id = ?').get(req.params.id);
  if (!server) return res.status(404).json({ error: 'Not found' });
  if (server.owner_id !== req.user.id && req.user.role !== 'admin') return res.status(403).json({ error: 'Forbidden' });

  const { name } = req.body;
  const catId = uuidv4();
  const pos = db.prepare('SELECT COUNT(*) as c FROM categories WHERE server_id = ?').get(req.params.id).c;
  db.prepare('INSERT INTO categories (id, server_id, name, position) VALUES (?, ?, ?, ?)').run(catId, req.params.id, name, pos);
  res.json(db.prepare('SELECT * FROM categories WHERE id = ?').get(catId));
});

// Get invite info
router.get('/invite/:code', (req, res) => {
  const server = db.prepare('SELECT id, name, icon, description FROM servers WHERE invite_code = ?').get(req.params.code);
  if (!server) return res.status(404).json({ error: 'Invalid invite' });
  const memberCount = db.prepare('SELECT COUNT(*) as count FROM server_members WHERE server_id = ?').get(server.id).count;
  res.json({ ...server, member_count: memberCount });
});

module.exports = router;
