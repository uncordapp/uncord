const express = require('express');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const { v4: uuidv4 } = require('uuid');
const db = require('../database');
const { JWT_SECRET } = require('../middleware/auth');

const router = express.Router();

function generateDiscriminator() {
  return String(Math.floor(Math.random() * 9999)).padStart(4, '0');
}

function sanitizeUser(user) {
  const { password, ...safe } = user;
  safe.badges = JSON.parse(safe.badges || '[]');
  return safe;
}

router.post('/register', (req, res) => {
  const { username, email, password } = req.body;
  if (!username || !email || !password) return res.status(400).json({ error: 'All fields required' });
  if (username.length < 2 || username.length > 32) return res.status(400).json({ error: 'Username must be 2-32 characters' });
  if (password.length < 6) return res.status(400).json({ error: 'Password must be at least 6 characters' });

  const allowReg = db.prepare("SELECT value FROM settings WHERE key='allow_registration'").get();
  if (allowReg?.value === 'false') return res.status(403).json({ error: 'Registration is disabled' });

  const existing = db.prepare('SELECT id FROM users WHERE email = ? OR username = ?').get(email, username);
  if (existing) return res.status(409).json({ error: 'Email or username already taken' });

  const hashed = bcrypt.hashSync(password, 10);
  const id = uuidv4();
  const discriminator = generateDiscriminator();

  // Check if first user -> make admin
  const userCount = db.prepare('SELECT COUNT(*) as count FROM users').get();
  const role = userCount.count === 0 ? 'admin' : 'user';

  db.prepare(`INSERT INTO users (id, username, discriminator, email, password, role, nitro, badges)
    VALUES (?, ?, ?, ?, ?, ?, 1, '[]')`).run(id, username, discriminator, email, hashed, role);

  const user = db.prepare('SELECT * FROM users WHERE id = ?').get(id);
  const token = jwt.sign({ id }, JWT_SECRET, { expiresIn: '30d' });

  res.json({ token, user: sanitizeUser(user) });
});

router.post('/login', (req, res) => {
  const { email, password } = req.body;
  if (!email || !password) return res.status(400).json({ error: 'All fields required' });

  const user = db.prepare('SELECT * FROM users WHERE email = ?').get(email);
  if (!user) return res.status(401).json({ error: 'Invalid credentials' });
  if (user.banned) return res.status(403).json({ error: `Banned: ${user.ban_reason || 'No reason given'}` });
  if (!bcrypt.compareSync(password, user.password)) return res.status(401).json({ error: 'Invalid credentials' });

  db.prepare('UPDATE users SET last_seen = unixepoch() WHERE id = ?').run(user.id);
  const token = jwt.sign({ id: user.id }, JWT_SECRET, { expiresIn: '30d' });

  res.json({ token, user: sanitizeUser(user) });
});

router.get('/me', require('../middleware/auth').auth, (req, res) => {
  res.json(sanitizeUser(req.user));
});

module.exports = router;
