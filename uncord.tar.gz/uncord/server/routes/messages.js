const express = require('express');
const { v4: uuidv4 } = require('uuid');
const { auth } = require('../middleware/auth');
const db = require('../database');
const router = express.Router();

function formatMsg(msg) {
  if (!msg) return null;
  msg.attachments = JSON.parse(msg.attachments || '[]');
  msg.embeds = JSON.parse(msg.embeds || '[]');
  msg.reactions = JSON.parse(msg.reactions || '{}');
  const author = db.prepare('SELECT id, username, discriminator, avatar, badges, role FROM users WHERE id = ?').get(msg.author_id);
  if (author) author.badges = JSON.parse(author.badges || '[]');
  msg.author = author;
  return msg;
}

// Get messages in channel
router.get('/channels/:channelId', auth, (req, res) => {
  const channel = db.prepare('SELECT * FROM channels WHERE id = ?').get(req.params.channelId);
  if (!channel) return res.status(404).json({ error: 'Channel not found' });

  const member = db.prepare('SELECT * FROM server_members WHERE user_id = ? AND server_id = ?').get(req.user.id, channel.server_id);
  if (!member) return res.status(403).json({ error: 'Not a member' });

  const { before, limit = 50 } = req.query;
  const lim = Math.min(parseInt(limit), 100);

  let msgs;
  if (before) {
    msgs = db.prepare(`SELECT * FROM messages WHERE channel_id = ? AND created_at < (SELECT created_at FROM messages WHERE id = ?) ORDER BY created_at DESC LIMIT ?`).all(req.params.channelId, before, lim);
  } else {
    msgs = db.prepare(`SELECT * FROM messages WHERE channel_id = ? ORDER BY created_at DESC LIMIT ?`).all(req.params.channelId, lim);
  }

  res.json(msgs.reverse().map(formatMsg));
});

// Send message
router.post('/channels/:channelId', auth, (req, res) => {
  const { content, attachments } = req.body;
  if (!content?.trim() && (!attachments || !attachments.length)) return res.status(400).json({ error: 'Empty message' });

  const channel = db.prepare('SELECT * FROM channels WHERE id = ?').get(req.params.channelId);
  if (!channel) return res.status(404).json({ error: 'Channel not found' });

  const member = db.prepare('SELECT * FROM server_members WHERE user_id = ? AND server_id = ?').get(req.user.id, channel.server_id);
  if (!member) return res.status(403).json({ error: 'Not a member' });

  const maxLen = parseInt(db.prepare("SELECT value FROM settings WHERE key='max_message_length'").get()?.value || '4000');
  if (content?.length > maxLen) return res.status(400).json({ error: `Message too long (max ${maxLen})` });

  const id = uuidv4();
  db.prepare(`INSERT INTO messages (id, channel_id, author_id, content, attachments) VALUES (?, ?, ?, ?, ?)`)
    .run(id, req.params.channelId, req.user.id, content || '', JSON.stringify(attachments || []));

  const msg = formatMsg(db.prepare('SELECT * FROM messages WHERE id = ?').get(id));
  res.json(msg);
});

// Edit message
router.patch('/channels/:channelId/:messageId', auth, (req, res) => {
  const msg = db.prepare('SELECT * FROM messages WHERE id = ? AND channel_id = ?').get(req.params.messageId, req.params.channelId);
  if (!msg) return res.status(404).json({ error: 'Not found' });
  if (msg.author_id !== req.user.id && req.user.role !== 'admin') return res.status(403).json({ error: 'Forbidden' });

  db.prepare('UPDATE messages SET content = ?, edited_at = unixepoch() WHERE id = ?').run(req.body.content, msg.id);
  res.json(formatMsg(db.prepare('SELECT * FROM messages WHERE id = ?').get(msg.id)));
});

// Delete message
router.delete('/channels/:channelId/:messageId', auth, (req, res) => {
  const msg = db.prepare('SELECT * FROM messages WHERE id = ? AND channel_id = ?').get(req.params.messageId, req.params.channelId);
  if (!msg) return res.status(404).json({ error: 'Not found' });

  const channel = db.prepare('SELECT * FROM channels WHERE id = ?').get(req.params.channelId);
  const server = db.prepare('SELECT * FROM servers WHERE id = ?').get(channel?.server_id);
  const canDelete = msg.author_id === req.user.id || req.user.role === 'admin' || server?.owner_id === req.user.id;
  if (!canDelete) return res.status(403).json({ error: 'Forbidden' });

  db.prepare('DELETE FROM messages WHERE id = ?').run(msg.id);
  res.json({ success: true });
});

// React to message
router.post('/channels/:channelId/:messageId/react', auth, (req, res) => {
  const { emoji } = req.body;
  const msg = db.prepare('SELECT * FROM messages WHERE id = ?').get(req.params.messageId);
  if (!msg) return res.status(404).json({ error: 'Not found' });

  const reactions = JSON.parse(msg.reactions || '{}');
  if (!reactions[emoji]) reactions[emoji] = [];
  const idx = reactions[emoji].indexOf(req.user.id);
  if (idx === -1) reactions[emoji].push(req.user.id);
  else reactions[emoji].splice(idx, 1);
  if (reactions[emoji].length === 0) delete reactions[emoji];

  db.prepare('UPDATE messages SET reactions = ? WHERE id = ?').run(JSON.stringify(reactions), msg.id);
  res.json({ reactions });
});

// DM routes
router.get('/dm/:userId', auth, (req, res) => {
  const participants = [req.user.id, req.params.userId].sort().join(',');
  let dm = db.prepare('SELECT * FROM direct_messages WHERE participants = ?').get(participants);
  if (!dm) {
    const dmId = uuidv4();
    db.prepare('INSERT INTO direct_messages (id, participants) VALUES (?, ?)').run(dmId, participants);
    dm = db.prepare('SELECT * FROM direct_messages WHERE id = ?').get(dmId);
  }

  const messages = db.prepare('SELECT * FROM dm_messages WHERE dm_id = ? ORDER BY created_at DESC LIMIT 50').all(dm.id);
  res.json({ dm_id: dm.id, messages: messages.reverse().map(m => {
    m.reactions = JSON.parse(m.reactions || '{}');
    m.attachments = JSON.parse(m.attachments || '[]');
    const author = db.prepare('SELECT id, username, discriminator, avatar, badges FROM users WHERE id = ?').get(m.author_id);
    if (author) author.badges = JSON.parse(author.badges || '[]');
    m.author = author;
    return m;
  })});
});

router.post('/dm/:userId', auth, (req, res) => {
  const { content } = req.body;
  if (!content?.trim()) return res.status(400).json({ error: 'Empty message' });

  const participants = [req.user.id, req.params.userId].sort().join(',');
  let dm = db.prepare('SELECT * FROM direct_messages WHERE participants = ?').get(participants);
  if (!dm) {
    const dmId = uuidv4();
    db.prepare('INSERT INTO direct_messages (id, participants) VALUES (?, ?)').run(dmId, participants);
    dm = db.prepare('SELECT * FROM direct_messages WHERE id = ?').get(dmId);
  }

  const id = uuidv4();
  db.prepare('INSERT INTO dm_messages (id, dm_id, author_id, content) VALUES (?, ?, ?, ?)').run(id, dm.id, req.user.id, content);
  const msg = db.prepare('SELECT * FROM dm_messages WHERE id = ?').get(id);
  msg.reactions = {};
  msg.attachments = [];
  const author = db.prepare('SELECT id, username, discriminator, avatar, badges FROM users WHERE id = ?').get(req.user.id);
  if (author) author.badges = JSON.parse(author.badges || '[]');
  msg.author = author;
  res.json(msg);
});

module.exports = router;
