const express = require('express');
const { v4: uuidv4 } = require('uuid');
const bcrypt = require('bcryptjs');
const { adminAuth } = require('../middleware/auth');
const db = require('../database');
const router = express.Router();

router.use(adminAuth);

function auditLog(adminId, action, targetType, targetId, details = {}) {
  db.prepare('INSERT INTO audit_log (id, admin_id, action, target_type, target_id, details) VALUES (?, ?, ?, ?, ?, ?)')
    .run(uuidv4(), adminId, action, targetType, targetId, JSON.stringify(details));
}

// ── Settings ──────────────────────────────────────────────
router.get('/settings', (req, res) => {
  const rows = db.prepare('SELECT * FROM settings').all();
  const settings = {};
  for (const r of rows) settings[r.key] = r.value;
  res.json(settings);
});

router.patch('/settings', (req, res) => {
  const allowed = ['platform_name', 'platform_description', 'allow_registration', 'max_servers_per_user', 'max_message_length'];
  for (const key of allowed) {
    if (req.body[key] !== undefined) {
      db.prepare('INSERT OR REPLACE INTO settings (key, value) VALUES (?, ?)').run(key, String(req.body[key]));
    }
  }
  auditLog(req.user.id, 'update_settings', 'settings', 'global', req.body);
  res.json({ success: true });
});

// ── Official Account ──────────────────────────────────────
router.post('/official-account', (req, res) => {
  const { username, bio } = req.body;
  const existingId = db.prepare("SELECT value FROM settings WHERE key='official_account_id'").get()?.value;
  if (existingId) {
    db.prepare('UPDATE users SET username = ?, bio = ?, badges = ? WHERE id = ?')
      .run(username || 'UnCord Official', bio || 'The official UnCord account.', JSON.stringify(['official', 'staff']), existingId);
    return res.json({ id: existingId, updated: true });
  }

  const id = uuidv4();
  const password = bcrypt.hashSync(uuidv4(), 10);
  db.prepare(`INSERT INTO users (id, username, discriminator, email, password, role, nitro, badges, bio)
    VALUES (?, ?, ?, ?, ?, ?, 1, ?, ?)`).run(
    id, username || 'UnCord', '0001',
    `official-${id}@uncord.internal`, password,
    'admin', JSON.stringify(['official', 'staff', 'verified']),
    bio || 'The official UnCord account.'
  );
  db.prepare("INSERT OR REPLACE INTO settings (key, value) VALUES ('official_account_id', ?)").run(id);
  auditLog(req.user.id, 'create_official_account', 'user', id, {});
  res.json({ id, created: true });
});

router.post('/official-account/send', (req, res) => {
  const { channel_id, content } = req.body;
  const officialId = db.prepare("SELECT value FROM settings WHERE key='official_account_id'").get()?.value;
  if (!officialId) return res.status(400).json({ error: 'Official account not created yet' });
  if (!channel_id || !content) return res.status(400).json({ error: 'channel_id and content required' });

  const channel = db.prepare('SELECT * FROM channels WHERE id = ?').get(channel_id);
  if (!channel) return res.status(404).json({ error: 'Channel not found' });

  const msgId = uuidv4();
  db.prepare('INSERT INTO messages (id, channel_id, author_id, content) VALUES (?, ?, ?, ?)').run(msgId, channel_id, officialId, content);
  const msg = db.prepare('SELECT * FROM messages WHERE id = ?').get(msgId);
  auditLog(req.user.id, 'send_official_message', 'message', msgId, { channel_id, content });
  res.json(msg);
});

// ── Users ─────────────────────────────────────────────────
router.get('/users', (req, res) => {
  const { search, page = 1, limit = 50 } = req.query;
  const offset = (page - 1) * limit;
  let users, total;

  if (search) {
    users = db.prepare(`SELECT * FROM users WHERE username LIKE ? OR email LIKE ? LIMIT ? OFFSET ?`).all(`%${search}%`, `%${search}%`, limit, offset);
    total = db.prepare(`SELECT COUNT(*) as c FROM users WHERE username LIKE ? OR email LIKE ?`).get(`%${search}%`, `%${search}%`).c;
  } else {
    users = db.prepare('SELECT * FROM users LIMIT ? OFFSET ?').all(limit, offset);
    total = db.prepare('SELECT COUNT(*) as c FROM users').get().c;
  }

  res.json({ users: users.map(u => { delete u.password; u.badges = JSON.parse(u.badges || '[]'); return u; }), total, page: parseInt(page), limit: parseInt(limit) });
});

router.get('/users/:id', (req, res) => {
  const user = db.prepare('SELECT * FROM users WHERE id = ?').get(req.params.id);
  if (!user) return res.status(404).json({ error: 'Not found' });
  delete user.password;
  user.badges = JSON.parse(user.badges || '[]');
  res.json(user);
});

router.patch('/users/:id', (req, res) => {
  const user = db.prepare('SELECT * FROM users WHERE id = ?').get(req.params.id);
  if (!user) return res.status(404).json({ error: 'Not found' });

  const allowed = ['username', 'email', 'bio', 'status', 'custom_status', 'role', 'account_standing',
    'nitro', 'badges', 'accent_color', 'pronouns', 'avatar', 'banner', 'banned', 'ban_reason', 'discriminator'];

  const updates = {};
  for (const key of allowed) {
    if (req.body[key] !== undefined) {
      updates[key] = key === 'badges' ? JSON.stringify(req.body[key]) : req.body[key];
    }
  }

  if (req.body.password) updates.password = bcrypt.hashSync(req.body.password, 10);

  if (Object.keys(updates).length) {
    const sets = Object.keys(updates).map(k => `${k} = ?`).join(', ');
    db.prepare(`UPDATE users SET ${sets} WHERE id = ?`).run(...Object.values(updates), req.params.id);
  }

  auditLog(req.user.id, 'edit_user', 'user', req.params.id, updates);
  const updated = db.prepare('SELECT * FROM users WHERE id = ?').get(req.params.id);
  delete updated.password;
  updated.badges = JSON.parse(updated.badges || '[]');
  res.json(updated);
});

router.post('/users/:id/badges', (req, res) => {
  const user = db.prepare('SELECT * FROM users WHERE id = ?').get(req.params.id);
  if (!user) return res.status(404).json({ error: 'Not found' });

  const { badge, action } = req.body;
  let badges = JSON.parse(user.badges || '[]');
  if (action === 'add' && !badges.includes(badge)) badges.push(badge);
  else if (action === 'remove') badges = badges.filter(b => b !== badge);

  db.prepare('UPDATE users SET badges = ? WHERE id = ?').run(JSON.stringify(badges), req.params.id);
  auditLog(req.user.id, `${action}_badge`, 'user', req.params.id, { badge });
  res.json({ badges });
});

router.post('/users/:id/nitro', (req, res) => {
  db.prepare('UPDATE users SET nitro = 1 WHERE id = ?').run(req.params.id);
  auditLog(req.user.id, 'grant_nitro', 'user', req.params.id, {});
  res.json({ success: true });
});

router.post('/users/nitro/all', (req, res) => {
  db.prepare('UPDATE users SET nitro = 1').run();
  auditLog(req.user.id, 'grant_nitro_all', 'users', 'all', {});
  res.json({ success: true });
});

// ── Servers ───────────────────────────────────────────────
router.get('/servers', (req, res) => {
  const { search, page = 1, limit = 50 } = req.query;
  const offset = (page - 1) * limit;
  let servers, total;

  if (search) {
    servers = db.prepare(`SELECT * FROM servers WHERE name LIKE ? LIMIT ? OFFSET ?`).all(`%${search}%`, limit, offset);
    total = db.prepare(`SELECT COUNT(*) as c FROM servers WHERE name LIKE ?`).get(`%${search}%`).c;
  } else {
    servers = db.prepare('SELECT * FROM servers LIMIT ? OFFSET ?').all(limit, offset);
    total = db.prepare('SELECT COUNT(*) as c FROM servers').get().c;
  }

  res.json({ servers: servers.map(s => { s.features = JSON.parse(s.features || '[]'); return s; }), total });
});

router.patch('/servers/:id', (req, res) => {
  const server = db.prepare('SELECT * FROM servers WHERE id = ?').get(req.params.id);
  if (!server) return res.status(404).json({ error: 'Not found' });

  const allowed = ['name', 'description', 'icon', 'banner', 'server_tag', 'community', 'verified',
    'partnered', 'boosts', 'boost_level', 'features', 'invite_code'];

  const updates = {};
  for (const key of allowed) {
    if (req.body[key] !== undefined) {
      updates[key] = key === 'features' ? JSON.stringify(req.body[key]) : req.body[key];
    }
  }

  if (Object.keys(updates).length) {
    const sets = Object.keys(updates).map(k => `${k} = ?`).join(', ');
    db.prepare(`UPDATE servers SET ${sets} WHERE id = ?`).run(...Object.values(updates), req.params.id);
  }

  auditLog(req.user.id, 'edit_server', 'server', req.params.id, updates);
  const updated = db.prepare('SELECT * FROM servers WHERE id = ?').get(req.params.id);
  updated.features = JSON.parse(updated.features || '[]');
  res.json(updated);
});

router.delete('/servers/:id', (req, res) => {
  db.prepare('DELETE FROM servers WHERE id = ?').run(req.params.id);
  auditLog(req.user.id, 'delete_server', 'server', req.params.id, {});
  res.json({ success: true });
});

// ── Stats ─────────────────────────────────────────────────
router.get('/stats', (req, res) => {
  res.json({
    users: db.prepare('SELECT COUNT(*) as c FROM users').get().c,
    servers: db.prepare('SELECT COUNT(*) as c FROM servers').get().c,
    messages: db.prepare('SELECT COUNT(*) as c FROM messages').get().c,
    banned: db.prepare('SELECT COUNT(*) as c FROM users WHERE banned = 1').get().c,
    online: db.prepare("SELECT COUNT(*) as c FROM users WHERE status != 'offline' AND last_seen > unixepoch() - 300").get().c,
  });
});

// ── Audit Log ─────────────────────────────────────────────
router.get('/audit-log', (req, res) => {
  const logs = db.prepare(`
    SELECT al.*, u.username as admin_username FROM audit_log al
    LEFT JOIN users u ON u.id = al.admin_id
    ORDER BY al.created_at DESC LIMIT 200
  `).all();
  res.json(logs.map(l => { l.details = JSON.parse(l.details || '{}'); return l; }));
});

module.exports = router;
