const express = require('express');
const { auth } = require('../middleware/auth');
const db = require('../database');
const router = express.Router();

function sanitizeUser(user) {
  if (!user) return null;
  const { password, email, ...safe } = user;
  safe.badges = JSON.parse(safe.badges || '[]');
  return safe;
}

router.get('/:id', auth, (req, res) => {
  const user = db.prepare('SELECT * FROM users WHERE id = ?').get(req.params.id);
  if (!user) return res.status(404).json({ error: 'User not found' });
  res.json(sanitizeUser(user));
});

router.patch('/me', auth, (req, res) => {
  const allowed = ['bio', 'status', 'custom_status', 'accent_color', 'pronouns', 'avatar', 'banner'];
  const updates = {};
  for (const key of allowed) {
    if (req.body[key] !== undefined) updates[key] = req.body[key];
  }
  if (Object.keys(updates).length === 0) return res.status(400).json({ error: 'Nothing to update' });

  const sets = Object.keys(updates).map(k => `${k} = ?`).join(', ');
  db.prepare(`UPDATE users SET ${sets} WHERE id = ?`).run(...Object.values(updates), req.user.id);

  const user = db.prepare('SELECT * FROM users WHERE id = ?').get(req.user.id);
  res.json(sanitizeUser(user));
});

// Friends
router.get('/me/friends', auth, (req, res) => {
  const friends = db.prepare(`
    SELECT u.*, f.status FROM users u
    JOIN friends f ON (f.friend_id = u.id AND f.user_id = ? AND f.status = 'accepted')
    OR (f.user_id = u.id AND f.friend_id = ? AND f.status = 'accepted')
  `).all(req.user.id, req.user.id);
  res.json(friends.map(sanitizeUser));
});

router.post('/me/friends/:id', auth, (req, res) => {
  const targetId = req.params.id;
  if (targetId === req.user.id) return res.status(400).json({ error: 'Cannot friend yourself' });
  const target = db.prepare('SELECT id FROM users WHERE id = ?').get(targetId);
  if (!target) return res.status(404).json({ error: 'User not found' });

  const existing = db.prepare('SELECT * FROM friends WHERE (user_id = ? AND friend_id = ?) OR (user_id = ? AND friend_id = ?)').get(req.user.id, targetId, targetId, req.user.id);
  if (existing) return res.status(409).json({ error: 'Friend request already exists' });

  db.prepare('INSERT INTO friends (user_id, friend_id, status) VALUES (?, ?, ?)').run(req.user.id, targetId, 'pending');
  res.json({ success: true });
});

router.patch('/me/friends/:id', auth, (req, res) => {
  const { action } = req.body;
  if (action === 'accept') {
    db.prepare("UPDATE friends SET status = 'accepted' WHERE user_id = ? AND friend_id = ?").run(req.params.id, req.user.id);
  } else if (action === 'reject' || action === 'remove') {
    db.prepare('DELETE FROM friends WHERE (user_id = ? AND friend_id = ?) OR (user_id = ? AND friend_id = ?)').run(req.user.id, req.params.id, req.params.id, req.user.id);
  }
  res.json({ success: true });
});

module.exports = router;
