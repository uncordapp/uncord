# UnCord 🎉

A fully self-hosted Discord-like platform built with Node.js, React, and SQLite.

## Features

- 💬 Real-time chat with Socket.io
- 🌐 Servers, channels, categories
- 📨 Direct messages
- 👥 Friends system
- 🛡️ Admin panel with full control
- ✦ All users get Nitro-equivalent by default
- 🏷️ Custom server tags (any length — no 4-char limit!)
- 🚀 Infinite server boosts + all features unlocked
- 🎖️ Custom badges for users
- 📢 Official account with broadcast messaging
- 🔒 JWT authentication
- 📁 File uploads (25MB max)
- 🎭 Full profile editing (bio, pronouns, avatar, banner, accent color)

## Quick Start

### Requirements
- Node.js 18+
- npm

### 1. Install dependencies
```bash
npm run install:all
```

### 2. Start in development mode
```bash
npm run dev
```
This runs the backend on port **3001** and the React frontend on port **3000**.

### 3. Start in production mode (single port)
```bash
npm run start:prod
```
Builds React and serves everything from port **3001**.

### 4. Custom port / environment
```bash
PORT=8080 JWT_SECRET=your-secret-here npm run start:prod
```

## First Use

1. Open `http://localhost:3000` (dev) or `http://localhost:3001` (prod)
2. Register an account — **the first user to register automatically becomes admin**
3. Create a server or join one with an invite code
4. Admins can access the **Admin Panel** via the shield icon in the server list

## Admin Panel

Access via the ⚙️ icon (admin users only). Features:
- **Overview** — live platform stats
- **Users** — search, edit every profile field, assign badges, ban/unban, grant Nitro, change roles
- **Servers** — edit any server, change tags (any length!), toggle features, set boost level
- **Official Account** — auto-generates an official UnCord account, send announcements to any channel
- **Settings** — change platform name, toggle registration, adjust limits
- **Audit Log** — full history of admin actions

## Sharing Invite Links

Every server gets an auto-generated invite code.  
Share: `http://your-domain/invite/CODE`

## Environment Variables

| Variable | Default | Description |
|---|---|---|
| `PORT` | `3001` | Server port |
| `JWT_SECRET` | `uncord-super-secret-...` | Change this in production! |
| `NODE_ENV` | `development` | Set to `production` for prod mode |

## File Structure

```
uncord/
├── server/
│   ├── index.js          # Express + Socket.io entry
│   ├── database.js       # SQLite setup + schema
│   ├── middleware/auth.js # JWT auth
│   ├── routes/
│   │   ├── auth.js       # Login/register
│   │   ├── users.js      # User profiles + friends
│   │   ├── servers.js    # Server/channel management
│   │   ├── messages.js   # Chat + DMs
│   │   └── admin.js      # Full admin API
│   └── socket/index.js   # Real-time events
├── client/
│   └── src/
│       ├── App.jsx
│       ├── store.js      # Zustand state
│       ├── components/
│       │   ├── layout/   # MainLayout, Sidebar, ServerList, MemberList, UserBar
│       │   ├── chat/     # ChatArea, MessageItem, MessageInput, DMArea
│       │   ├── admin/    # AdminPanel (full control center)
│       │   └── user/     # Avatar
│       └── pages/        # AuthPage, InvitePage
└── data/
    ├── uncord.db         # SQLite database (auto-created)
    └── uploads/          # Uploaded files (auto-created)
```

## Notes

- SQLite database is created automatically at `data/uncord.db`
- Uploaded files stored at `data/uploads/`
- No external database required — everything runs locally
- All users get `nitro: 1` by default — all premium features unlocked platform-wide
