import React, { useState } from 'react';
import api from '../utils/api';
import { useStore } from '../store';

export default function AuthPage() {
  const [mode, setMode] = useState('login');
  const [form, setForm] = useState({ username: '', email: '', password: '' });
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);
  const { setToken, setUser } = useStore();

  const handle = async (e) => {
    e.preventDefault();
    setError(''); setLoading(true);
    try {
      const data = await api.post(`/auth/${mode}`, form);
      setToken(data.token);
      setUser(data.user);
    } catch (err) {
      setError(err.error || 'Something went wrong');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div style={{
      minHeight: '100vh', display: 'flex', alignItems: 'center', justifyContent: 'center',
      background: 'linear-gradient(135deg, #5865f2 0%, #3442d9 50%, #7289da 100%)'
    }}>
      <div style={{
        background: '#313338', borderRadius: 8, padding: '32px 32px', width: 480,
        boxShadow: '0 8px 32px rgba(0,0,0,0.5)'
      }}>
        {/* Logo */}
        <div style={{ textAlign: 'center', marginBottom: 24 }}>
          <div style={{ fontSize: 32, fontWeight: 900, color: '#5865f2', letterSpacing: -1 }}>UnCord</div>
          <div style={{ color: '#b5bac1', marginTop: 8, fontSize: 14 }}>
            {mode === 'login' ? 'Welcome back!' : 'Create an account'}
          </div>
        </div>

        <form onSubmit={handle}>
          {mode === 'register' && (
            <Field label="Username" value={form.username} onChange={v => setForm(f => ({ ...f, username: v }))} placeholder="cooluser" />
          )}
          <Field label="Email" type="email" value={form.email} onChange={v => setForm(f => ({ ...f, email: v }))} placeholder="you@example.com" />
          <Field label="Password" type="password" value={form.password} onChange={v => setForm(f => ({ ...f, password: v }))} placeholder="••••••••" />

          {error && <div style={{ color: '#f23f42', fontSize: 13, marginBottom: 12 }}>{error}</div>}

          <button type="submit" disabled={loading} style={{
            width: '100%', padding: '12px', background: '#5865f2', color: '#fff',
            border: 'none', borderRadius: 4, fontSize: 16, fontWeight: 600, cursor: 'pointer',
            opacity: loading ? 0.7 : 1, marginTop: 8
          }}>
            {loading ? 'Loading...' : mode === 'login' ? 'Log In' : 'Register'}
          </button>
        </form>

        <div style={{ marginTop: 16, fontSize: 14, color: '#b5bac1' }}>
          {mode === 'login' ? (
            <>Need an account? <span onClick={() => setMode('register')} style={{ color: '#00a8fc', cursor: 'pointer' }}>Register</span></>
          ) : (
            <>Already have an account? <span onClick={() => setMode('login')} style={{ color: '#00a8fc', cursor: 'pointer' }}>Log In</span></>
          )}
        </div>
      </div>
    </div>
  );
}

function Field({ label, type = 'text', value, onChange, placeholder }) {
  return (
    <div style={{ marginBottom: 16 }}>
      <label style={{ display: 'block', color: '#b5bac1', fontSize: 12, fontWeight: 700, textTransform: 'uppercase', letterSpacing: 0.5, marginBottom: 8 }}>
        {label}
      </label>
      <input
        type={type} value={value} placeholder={placeholder}
        onChange={e => onChange(e.target.value)}
        style={{
          width: '100%', padding: '10px 12px', background: '#1e1f22', border: '1px solid #1e1f22',
          borderRadius: 4, color: '#dbdee1', fontSize: 16, outline: 'none'
        }}
        onFocus={e => e.target.style.borderColor = '#5865f2'}
        onBlur={e => e.target.style.borderColor = '#1e1f22'}
      />
    </div>
  );
}
