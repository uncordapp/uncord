import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import api from '../utils/api';
import { useStore } from '../store';

export default function InvitePage() {
  const { code } = useParams();
  const navigate = useNavigate();
  const { token, addServer, setActiveServer } = useStore();
  const [server, setServer] = useState(null);
  const [error, setError] = useState('');
  const [joining, setJoining] = useState(false);

  useEffect(() => {
    api.get(`/servers/invite/${code}`).then(setServer).catch(() => setError('Invalid or expired invite link.'));
  }, [code]);

  const join = async () => {
    if (!token) { navigate('/'); return; }
    setJoining(true);
    try {
      const s = await api.post(`/servers/join/${code}`);
      addServer(s);
      navigate('/');
    } catch (e) { setError(e.error || 'Failed to join'); }
    setJoining(false);
  };

  return (
    <div style={{ minHeight: '100vh', display: 'flex', alignItems: 'center', justifyContent: 'center', background: '#313338' }}>
      <div style={{ background: '#2b2d31', borderRadius: 12, padding: 32, width: 440, textAlign: 'center', boxShadow: '0 8px 32px rgba(0,0,0,0.5)' }}>
        {error ? (
          <div>
            <div style={{ fontSize: 48, marginBottom: 16 }}>😕</div>
            <div style={{ fontSize: 20, fontWeight: 700, color: '#f2f3f5', marginBottom: 8 }}>Invalid Invite</div>
            <div style={{ color: '#80848e', marginBottom: 24 }}>{error}</div>
            <button onClick={() => navigate('/')} style={{ padding: '12px 24px', background: '#5865f2', color: '#fff', border: 'none', borderRadius: 6, cursor: 'pointer', fontWeight: 700 }}>
              Go Home
            </button>
          </div>
        ) : server ? (
          <div>
            <div style={{ width: 72, height: 72, borderRadius: 24, background: '#5865f2', display: 'flex', alignItems: 'center', justifyContent: 'center', fontWeight: 800, color: '#fff', fontSize: 28, margin: '0 auto 16px', overflow: 'hidden' }}>
              {server.icon ? <img src={server.icon} alt="" style={{ width: '100%', height: '100%', objectFit: 'cover' }} /> : server.name[0].toUpperCase()}
            </div>
            <div style={{ fontSize: 11, color: '#80848e', textTransform: 'uppercase', letterSpacing: 1, marginBottom: 8 }}>You've been invited to join</div>
            <div style={{ fontSize: 24, fontWeight: 800, color: '#f2f3f5', marginBottom: 8 }}>{server.name}</div>
            {server.description && <div style={{ fontSize: 14, color: '#80848e', marginBottom: 16 }}>{server.description}</div>}
            <div style={{ fontSize: 13, color: '#80848e', marginBottom: 24 }}>👥 {server.member_count} members</div>
            <button onClick={join} disabled={joining} style={{ padding: '12px 32px', background: '#23a559', color: '#fff', border: 'none', borderRadius: 6, cursor: 'pointer', fontWeight: 700, fontSize: 16, width: '100%' }}>
              {joining ? 'Joining...' : 'Accept Invite'}
            </button>
            <button onClick={() => navigate('/')} style={{ marginTop: 12, padding: '10px', background: 'transparent', color: '#80848e', border: 'none', cursor: 'pointer', fontSize: 14, width: '100%' }}>
              Maybe later
            </button>
          </div>
        ) : (
          <div style={{ color: '#80848e' }}>Loading invite...</div>
        )}
      </div>
    </div>
  );
}
