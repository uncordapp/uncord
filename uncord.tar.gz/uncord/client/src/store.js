import { create } from 'zustand';

export const useStore = create((set, get) => ({
  // Auth
  user: null,
  token: localStorage.getItem('uncord_token'),
  setUser: (user) => set({ user }),
  setToken: (token) => {
    localStorage.setItem('uncord_token', token);
    set({ token });
  },
  logout: () => {
    localStorage.removeItem('uncord_token');
    set({ user: null, token: null, servers: [], activeServer: null, activeChannel: null, messages: {} });
  },

  // Servers
  servers: [],
  activeServer: null,
  setServers: (servers) => set({ servers }),
  addServer: (server) => set(s => ({ servers: [...s.servers, server] })),
  updateServer: (server) => set(s => ({ servers: s.servers.map(sv => sv.id === server.id ? server : sv), activeServer: s.activeServer?.id === server.id ? server : s.activeServer })),
  removeServer: (id) => set(s => ({ servers: s.servers.filter(sv => sv.id !== id) })),
  setActiveServer: (server) => set({ activeServer: server, activeChannel: null }),

  // Channels
  activeChannel: null,
  setActiveChannel: (channel) => set({ activeChannel: channel }),

  // Messages
  messages: {}, // channelId -> message[]
  setMessages: (channelId, msgs) => set(s => ({ messages: { ...s.messages, [channelId]: msgs } })),
  addMessage: (channelId, msg) => set(s => ({
    messages: { ...s.messages, [channelId]: [...(s.messages[channelId] || []), msg] }
  })),
  updateMessage: (channelId, messageId, data) => set(s => ({
    messages: {
      ...s.messages,
      [channelId]: (s.messages[channelId] || []).map(m => m.id === messageId ? { ...m, ...data } : m)
    }
  })),
  deleteMessage: (channelId, messageId) => set(s => ({
    messages: { ...s.messages, [channelId]: (s.messages[channelId] || []).filter(m => m.id !== messageId) }
  })),
  prependMessages: (channelId, msgs) => set(s => ({
    messages: { ...s.messages, [channelId]: [...msgs, ...(s.messages[channelId] || [])] }
  })),

  // Members / online status
  onlineUsers: {}, // userId -> { status, custom_status }
  setUserStatus: (userId, status, custom_status) => set(s => ({
    onlineUsers: { ...s.onlineUsers, [userId]: { status, custom_status } }
  })),

  // DMs
  openDMs: [], // [{ user, dm_id }]
  activeDM: null,
  setActiveDM: (dm) => set({ activeDM: dm, activeServer: null, activeChannel: null }),
  addDM: (dm) => set(s => ({ openDMs: s.openDMs.find(d => d.user.id === dm.user.id) ? s.openDMs : [...s.openDMs, dm] })),

  // Typing
  typing: {}, // channelId -> [{ userId, username }]
  setTyping: (channelId, users) => set(s => ({ typing: { ...s.typing, [channelId]: users } })),

  // UI
  showAdmin: false,
  setShowAdmin: (v) => set({ showAdmin: v }),
  modal: null,
  setModal: (modal) => set({ modal }),
}));
