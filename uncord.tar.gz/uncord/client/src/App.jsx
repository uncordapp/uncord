import React, { useEffect } from 'react';
import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { useStore } from './store';
import api, { connectSocket, disconnectSocket } from './utils/api';
import MainLayout from './components/layout/MainLayout';
import AuthPage from './pages/AuthPage';
import InvitePage from './pages/InvitePage';
import './index.css';

export default function App() {
  const { token, user, setUser, setServers, setToken, logout } = useStore();

  useEffect(() => {
    if (!token) return;
    api.get('/auth/me')
      .then(u => {
        setUser(u);
        return api.get('/servers/me');
      })
      .then(servers => setServers(servers))
      .catch(() => logout());
  }, [token]);

  useEffect(() => {
    if (!token || !user) return;
    const socket = connectSocket(token);

    socket.on('user:status', ({ userId, status, custom_status }) => {
      useStore.getState().setUserStatus(userId, status, custom_status);
    });

    socket.on('message:new', (msg) => {
      useStore.getState().addMessage(msg.channel_id, msg);
    });

    socket.on('message:update', ({ message_id, content, edited_at }) => {
      const msgs = useStore.getState().messages;
      for (const [cid, list] of Object.entries(msgs)) {
        if (list.find(m => m.id === message_id)) {
          useStore.getState().updateMessage(cid, message_id, { content, edited_at });
          break;
        }
      }
    });

    socket.on('message:delete', ({ message_id, channel_id }) => {
      useStore.getState().deleteMessage(channel_id, message_id);
    });

    socket.on('message:reaction', ({ message_id, reactions }) => {
      const msgs = useStore.getState().messages;
      for (const [cid, list] of Object.entries(msgs)) {
        if (list.find(m => m.id === message_id)) {
          useStore.getState().updateMessage(cid, message_id, { reactions });
          break;
        }
      }
    });

    socket.on('typing:start', ({ channel_id, user: typingUser }) => {
      const current = useStore.getState().typing[channel_id] || [];
      if (!current.find(u => u.userId === typingUser.id)) {
        useStore.getState().setTyping(channel_id, [...current, { userId: typingUser.id, username: typingUser.username }]);
      }
    });

    socket.on('typing:stop', ({ channel_id, userId }) => {
      const current = useStore.getState().typing[channel_id] || [];
      useStore.getState().setTyping(channel_id, current.filter(u => u.userId !== userId));
    });

    socket.on('dm:message', ({ message, from_user_id, to_user_id }) => {
      const otherId = from_user_id === user.id ? to_user_id : from_user_id;
      useStore.getState().addMessage(`dm:${otherId}`, message);
    });

    return () => disconnectSocket();
  }, [token, user?.id]);

  if (!token || !user) {
    return (
      <BrowserRouter>
        <Routes>
          <Route path="/invite/:code" element={<InvitePage />} />
          <Route path="*" element={<AuthPage />} />
        </Routes>
      </BrowserRouter>
    );
  }

  return (
    <BrowserRouter>
      <Routes>
        <Route path="/invite/:code" element={<InvitePage />} />
        <Route path="/*" element={<MainLayout />} />
      </Routes>
    </BrowserRouter>
  );
}
