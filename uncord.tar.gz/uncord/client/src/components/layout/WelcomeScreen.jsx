import React from 'react';
import { useStore } from '../../store';

export default function WelcomeScreen() {
  const { user, servers } = useStore();
  return (
    <div style={{ flex: 1, display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', background: '#313338', gap: 16 }}>
      <div style={{ fontSize: 64 }}>🎉</div>
      <div style={{ fontSize: 28, fontWeight: 700, color: '#f2f3f5' }}>Welcome to UnCord, {user?.username}!</div>
      <div style={{ fontSize: 16, color: '#80848e', textAlign: 'center', maxWidth: 420 }}>
        {servers.length === 0
          ? 'Create or join a server to get started. Click the + button in the left sidebar.'
          : 'Select a server from the sidebar to start chatting.'}
      </div>
      <div style={{ display: 'flex', gap: 24, marginTop: 16 }}>
        <Stat label="Servers" value={servers.length} />
        <Stat label="Status" value={user?.account_standing === 'good' ? '✅ Good' : user?.account_standing} />
        {user?.nitro && <Stat label="Nitro" value="✦ Active" color="#ff73fa" />}
      </div>
    </div>
  );
}

function Stat({ label, value, color }) {
  return (
    <div style={{ textAlign: 'center' }}>
      <div style={{ fontSize: 22, fontWeight: 700, color: color || '#f2f3f5' }}>{value}</div>
      <div style={{ fontSize: 13, color: '#80848e' }}>{label}</div>
    </div>
  );
}
