import React, { useState } from 'react';
import { useStore } from '../../store';
import api from '../../utils/api';
import Avatar from '../user/Avatar';

export default function ServerList() {
  const { servers, activeServer, setActiveServer, addServer, user, setShowAdmin } = useStore();
  const [showCreate, setShowCreate] = useState(false);
  const [showJoin, setShowJoin] = useState(false);
  const [serverName, setServerName] = useState('');
  const [inviteCode, setInviteCode] = useState('');

  const createServer = async () => {
    if (!serverName.trim()) return;
    try {
      const server = await api.post('/servers', { name: serverName });
      addServer(server);
      setShowCreate(false); setServerName('');
    } catch {}
  };

  const joinServer = async () => {
    if (!inviteCode.trim()) return;
    try {
      const server = await api.post(`/servers/join/${inviteCode.trim()}`);
      addServer(server);
      setShowJoin(false); setInviteCode('');
    } catch {}
  };

  const selectServer = async (server) => {
    try {
      const full = await api.get(`/servers/${server.id}`);
      setActiveServer(full);
    } catch {}
  };

  return (
    <div style={{
      width: 72, minWidth: 72, background: '#1e1f22', display: 'flex', flexDirection: 'column',
      alignItems: 'center', padding: '12px 0', gap: 8, overflowY: 'auto', overflowX: 'hidden'
    }}>
      {/* DMs button */}
      <ServerIcon
        label="Direct Messages"
        active={!activeServer}
        onClick={() => useStore.getState().setActiveServer(null)}
        color="#5865f2"
      >
        <svg width="24" height="24" viewBox="0 0 24 24" fill="white">
          <path d="M12 2C6.486 2 2 6.486 2 12s4.486 10 10 10 10-4.486 10-10S17.514 2 12 2zm0 18c-4.411 0-8-3.589-8-8s3.589-8 8-8 8 3.589 8 8-3.589 8-8 8z"/>
          <path d="M11 11h2v6h-2zm0-4h2v2h-2z"/>
        </svg>
      </ServerIcon>

      <Divider />

      {servers.map(s => (
        <ServerIcon
          key={s.id}
          label={s.name}
          active={activeServer?.id === s.id}
          onClick={() => selectServer(s)}
          color="#5865f2"
          img={s.icon}
          name={s.name}
          tag={s.server_tag}
        />
      ))}

      <Divider />

      {/* Add server */}
      <ServerIcon label="Add a Server" onClick={() => setShowCreate(true)} color="#23a559">
        <svg width="18" height="18" viewBox="0 0 18 18" fill="white"><path d="M15.5 8H10V2.5a1 1 0 0 0-2 0V8H2.5a1 1 0 0 0 0 2H8v5.5a1 1 0 0 0 2 0V10h5.5a1 1 0 0 0 0-2z"/></svg>
      </ServerIcon>

      {/* Join server */}
      <ServerIcon label="Join a Server" onClick={() => setShowJoin(true)} color="#5865f2">
        <svg width="18" height="18" viewBox="0 0 18 18" fill="white"><path d="M9 1a8 8 0 1 0 0 16A8 8 0 0 0 9 1zm4 9h-3v3a1 1 0 1 1-2 0v-3H5a1 1 0 1 1 0-2h3V5a1 1 0 1 1 2 0v3h3a1 1 0 1 1 0 2z"/></svg>
      </ServerIcon>

      {/* Admin panel */}
      {user?.role === 'admin' && (
        <ServerIcon label="Admin Panel" onClick={() => setShowAdmin(true)} color="#f0b232">
          <svg width="18" height="18" viewBox="0 0 24 24" fill="white"><path d="M12 2L4 5v6c0 5.55 3.84 10.74 8 12 4.16-1.26 8-6.45 8-12V5l-8-3zm0 10.99h6c-.47 3.57-3.18 6.73-6 7.7V13H6V7.65l6-2.25v7.59z"/></svg>
        </ServerIcon>
      )}

      {/* Modals */}
      {showCreate && (
        <Modal title="Create Server" onClose={() => setShowCreate(false)} onConfirm={createServer} confirmLabel="Create">
          <input value={serverName} onChange={e => setServerName(e.target.value)} placeholder="My Awesome Server"
            onKeyDown={e => e.key === 'Enter' && createServer()}
            style={{ width: '100%', padding: '10px 12px', background: '#1e1f22', border: 'none', borderRadius: 4, color: '#dbdee1', fontSize: 15 }} />
        </Modal>
      )}

      {showJoin && (
        <Modal title="Join Server" onClose={() => setShowJoin(false)} onConfirm={joinServer} confirmLabel="Join">
          <input value={inviteCode} onChange={e => setInviteCode(e.target.value)} placeholder="Invite code or link"
            onKeyDown={e => e.key === 'Enter' && joinServer()}
            style={{ width: '100%', padding: '10px 12px', background: '#1e1f22', border: 'none', borderRadius: 4, color: '#dbdee1', fontSize: 15 }} />
        </Modal>
      )}
    </div>
  );
}

function ServerIcon({ label, active, onClick, color, children, img, name, tag }) {
  const [hovered, setHovered] = useState(false);
  const show = active || hovered;
  return (
    <div style={{ position: 'relative', display: 'flex', alignItems: 'center' }}>
      {/* Active/hover pill */}
      <div style={{
        position: 'absolute', left: -4, width: 4, borderRadius: '0 4px 4px 0', background: '#fff',
        height: show ? (active ? 40 : 20) : 0, transition: 'height 0.15s ease', top: '50%', transform: 'translateY(-50%)'
      }} />
      <div
        title={label}
        onClick={onClick}
        onMouseEnter={() => setHovered(true)}
        onMouseLeave={() => setHovered(false)}
        style={{
          width: 48, height: 48, borderRadius: show ? 16 : 24, background: img ? 'transparent' : (active ? color : '#36393f'),
          display: 'flex', alignItems: 'center', justifyContent: 'center', cursor: 'pointer',
          transition: 'border-radius 0.15s ease, background 0.15s ease', overflow: 'hidden',
          flexShrink: 0, position: 'relative'
        }}
      >
        {img ? (
          <img src={img.startsWith('http') ? img : img} alt={name} style={{ width: '100%', height: '100%', objectFit: 'cover' }} />
        ) : name ? (
          <span style={{ color: '#fff', fontWeight: 700, fontSize: 16 }}>
            {name.split(' ').map(w => w[0]).join('').slice(0, 2).toUpperCase()}
          </span>
        ) : children}
        {tag && (
          <div style={{
            position: 'absolute', bottom: 0, right: 0, background: '#5865f2',
            color: '#fff', fontSize: 8, fontWeight: 700, padding: '1px 3px', borderRadius: '4px 0 4px 0'
          }}>{tag}</div>
        )}
      </div>
    </div>
  );
}

function Divider() {
  return <div style={{ width: 32, height: 2, background: '#35363c', borderRadius: 1, margin: '4px 0' }} />;
}

function Modal({ title, onClose, onConfirm, confirmLabel, children }) {
  return (
    <div style={{
      position: 'fixed', inset: 0, background: 'rgba(0,0,0,0.7)', display: 'flex',
      alignItems: 'center', justifyContent: 'center', zIndex: 1000
    }} onClick={onClose}>
      <div onClick={e => e.stopPropagation()} style={{
        background: '#313338', borderRadius: 8, padding: 24, width: 440,
        boxShadow: '0 8px 32px rgba(0,0,0,0.5)'
      }}>
        <div style={{ fontSize: 20, fontWeight: 700, color: '#f2f3f5', marginBottom: 16 }}>{title}</div>
        {children}
        <div style={{ display: 'flex', gap: 8, marginTop: 20, justifyContent: 'flex-end' }}>
          <button onClick={onClose} style={{ padding: '10px 16px', background: 'transparent', color: '#dbdee1', border: 'none', borderRadius: 4, cursor: 'pointer' }}>Cancel</button>
          <button onClick={onConfirm} style={{ padding: '10px 16px', background: '#5865f2', color: '#fff', border: 'none', borderRadius: 4, cursor: 'pointer', fontWeight: 600 }}>{confirmLabel}</button>
        </div>
      </div>
    </div>
  );
}
