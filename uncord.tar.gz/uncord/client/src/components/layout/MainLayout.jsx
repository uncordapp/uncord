import React from 'react';
import { useStore } from '../../store';
import ServerList from './ServerList';
import Sidebar from './Sidebar';
import ChatArea from '../chat/ChatArea';
import MemberList from './MemberList';
import AdminPanel from '../admin/AdminPanel';
import UserBar from './UserBar';
import DMArea from '../chat/DMArea';
import WelcomeScreen from './WelcomeScreen';

export default function MainLayout() {
  const { showAdmin, activeServer, activeDM, setShowAdmin } = useStore();

  if (showAdmin) return <AdminPanel onClose={() => setShowAdmin(false)} />;

  return (
    <div style={{ display: 'flex', height: '100vh', overflow: 'hidden', background: '#313338' }}>
      {/* Server list */}
      <ServerList />

      {/* Sidebar - channels/DMs */}
      <Sidebar />

      {/* Main content */}
      <div style={{ flex: 1, display: 'flex', flexDirection: 'column', overflow: 'hidden' }}>
        {activeDM ? (
          <DMArea />
        ) : activeServer ? (
          <div style={{ flex: 1, display: 'flex', overflow: 'hidden' }}>
            <ChatArea />
            <MemberList />
          </div>
        ) : (
          <WelcomeScreen />
        )}
      </div>
    </div>
  );
}
