import React, { useState } from 'react';
import { useStore } from '../../store';
import api from '../../utils/api';
import UserBar from './UserBar';

export default function Sidebar() {
  const { activeServer, activeChannel, setActiveChannel, user, activeDM, setActiveDM, openDMs, setActiveServer } = useStore();

  if (!activeServer) return <DMSidebar />;

  const categories = activeServer.categories || [];
  const channels = activeServer.channels || [];
  const uncategorized = channels.filter(c => !c.category_id);

  const selectChannel = (ch) => {
    setActiveChannel(ch);
    api.get(`/messages/channels/${ch.id}`).then(msgs => {
      useStore.getState().setMessages(ch.id, msgs);
    }).catch(() => {});
  };

  return (
    <div style={{ width: 240, background: '#2b2d31', display: 'flex', flexDirection: 'column', flexShrink: 0 }}>
      {/* Server header */}
      <div style={{
        padding: '16px 12px', borderBottom: '1px solid #1e1f22', fontWeight: 700,
        color: '#f2f3f5', display: 'flex', alignItems: 'center', justifyContent: 'space-between',
        cursor: 'pointer', ':hover': { background: '#35363c' }
      }}>
        <span style={{ fontSize: 15, truncate: true }}>{activeServer.name}</span>
        <span style={{ color: '#b5bac1', fontSize: 18 }}>⌄</span>
      </div>

      {/* Channels */}
      <div style={{ flex: 1, overflowY: 'auto', padding: '8px 0' }}>
        {uncategorized.map(ch => (
          <ChannelItem key={ch.id} channel={ch} active={activeChannel?.id === ch.id} onClick={() => selectChannel(ch)} />
        ))}
        {categories.map(cat => (
          <div key={cat.id}>
            <div style={{ padding: '16px 16px 4px', fontSize: 11, fontWeight: 700, color: '#80848e', textTransform: 'uppercase', letterSpacing: 0.5 }}>
              {cat.name}
            </div>
            {channels.filter(c => c.category_id === cat.id).map(ch => (
              <ChannelItem key={ch.id} channel={ch} active={activeChannel?.id === ch.id} onClick={() => selectChannel(ch)} />
            ))}
          </div>
        ))}
      </div>

      <UserBar />
    </div>
  );
}

function DMSidebar() {
  const { user, openDMs, activeDM, setActiveDM } = useStore();
  const [search, setSearch] = useState('');
  const [friends, setFriends] = useState([]);
  const [showFriends, setShowFriends] = useState(false);

  React.useEffect(() => {
    api.get('/users/me/friends').then(setFriends).catch(() => {});
  }, []);

  const openDM = async (friend) => {
    useStore.getState().addDM({ user: friend });
    setActiveDM({ user: friend });
    const { messages } = await api.get(`/messages/dm/${friend.id}`);
    useStore.getState().setMessages(`dm:${friend.id}`, messages);
  };

  return (
    <div style={{ width: 240, background: '#2b2d31', display: 'flex', flexDirection: 'column', flexShrink: 0 }}>
      <div style={{ padding: '12px 16px' }}>
        <div style={{
          background: '#1e1f22', borderRadius: 4, padding: '6px 8px', display: 'flex', alignItems: 'center', gap: 8
        }}>
          <span style={{ color: '#80848e' }}>🔍</span>
          <input value={search} onChange={e => setSearch(e.target.value)} placeholder="Find or start a conversation"
            style={{ background: 'none', border: 'none', color: '#dbdee1', fontSize: 14, flex: 1, outline: 'none' }} />
        </div>
      </div>

      <div style={{ flex: 1, overflowY: 'auto' }}>
        <div style={{ padding: '8px 8px 4px' }}>
          <SidebarItem icon="👥" label="Friends" active={showFriends} onClick={() => setShowFriends(!showFriends)} />
        </div>

        <div style={{ padding: '8px 8px 4px' }}>
          <div style={{ padding: '4px 8px', fontSize: 11, fontWeight: 700, color: '#80848e', textTransform: 'uppercase', letterSpacing: 0.5 }}>
            Direct Messages
          </div>
          {friends.map(f => (
            <DMItem key={f.id} user={f} active={activeDM?.user?.id === f.id} onClick={() => openDM(f)} />
          ))}
        </div>
      </div>

      <UserBar />
    </div>
  );
}

function ChannelItem({ channel, active, onClick }) {
  const icon = channel.type === 'voice' ? '🔊' : channel.nsfw ? '🔞' : '#';
  return (
    <div onClick={onClick} style={{
      display: 'flex', alignItems: 'center', gap: 8, padding: '6px 16px', margin: '1px 8px',
      borderRadius: 4, cursor: 'pointer', color: active ? '#dbdee1' : '#80848e',
      background: active ? 'rgba(255,255,255,0.08)' : 'transparent',
      ':hover': { background: 'rgba(255,255,255,0.06)', color: '#dbdee1' },
      transition: 'background 0.1s, color 0.1s'
    }}
      onMouseEnter={e => { if (!active) { e.currentTarget.style.background = 'rgba(255,255,255,0.06)'; e.currentTarget.style.color = '#dbdee1'; } }}
      onMouseLeave={e => { if (!active) { e.currentTarget.style.background = 'transparent'; e.currentTarget.style.color = '#80848e'; } }}
    >
      <span style={{ fontSize: 18, width: 20, textAlign: 'center', flexShrink: 0 }}>{icon}</span>
      <span style={{ fontSize: 15, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{channel.name}</span>
    </div>
  );
}

function SidebarItem({ icon, label, active, onClick }) {
  return (
    <div onClick={onClick} style={{
      display: 'flex', alignItems: 'center', gap: 12, padding: '8px 12px', borderRadius: 4,
      cursor: 'pointer', color: active ? '#dbdee1' : '#80848e',
      background: active ? 'rgba(255,255,255,0.08)' : 'transparent',
    }}
      onMouseEnter={e => { e.currentTarget.style.background = 'rgba(255,255,255,0.06)'; e.currentTarget.style.color = '#dbdee1'; }}
      onMouseLeave={e => { if (!active) { e.currentTarget.style.background = 'transparent'; e.currentTarget.style.color = '#80848e'; } }}
    >
      <span style={{ fontSize: 20 }}>{icon}</span>
      <span style={{ fontSize: 15, fontWeight: 500 }}>{label}</span>
    </div>
  );
}

function DMItem({ user, active, onClick }) {
  const statusColor = { online: '#23a559', idle: '#f0b232', dnd: '#f23f42', offline: '#80848e', invisible: '#80848e' };
  const onlineUsers = useStore.getState().onlineUsers;
  const status = onlineUsers[user.id]?.status || user.status || 'offline';

  return (
    <div onClick={onClick} style={{
      display: 'flex', alignItems: 'center', gap: 12, padding: '6px 12px', margin: '1px 8px',
      borderRadius: 4, cursor: 'pointer', color: active ? '#dbdee1' : '#80848e',
      background: active ? 'rgba(255,255,255,0.08)' : 'transparent',
    }}
      onMouseEnter={e => { if (!active) { e.currentTarget.style.background = 'rgba(255,255,255,0.06)'; e.currentTarget.style.color = '#dbdee1'; } }}
      onMouseLeave={e => { if (!active) { e.currentTarget.style.background = 'transparent'; e.currentTarget.style.color = '#80848e'; } }}
    >
      <div style={{ position: 'relative', flexShrink: 0 }}>
        <div style={{ width: 32, height: 32, borderRadius: '50%', background: '#5865f2', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 14, fontWeight: 700, color: '#fff', overflow: 'hidden' }}>
          {user.avatar ? <img src={user.avatar} alt="" style={{ width: '100%', height: '100%', objectFit: 'cover' }} /> : user.username[0].toUpperCase()}
        </div>
        <div style={{ position: 'absolute', bottom: -1, right: -1, width: 12, height: 12, borderRadius: '50%', background: statusColor[status] || '#80848e', border: '2px solid #2b2d31' }} />
      </div>
      <span style={{ fontSize: 14, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{user.username}</span>
    </div>
  );
}
