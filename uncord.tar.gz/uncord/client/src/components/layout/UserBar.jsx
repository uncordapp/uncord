import React, { useState } from 'react';
import { useStore } from '../../store';
import api from '../../utils/api';
import { getSocket } from '../../utils/api';

export default function UserBar() {
  const { user, logout, setUser } = useStore();
  const [showMenu, setShowMenu] = useState(false);

  if (!user) return null;

  const statusColor = { online: '#23a559', idle: '#f0b232', dnd: '#f23f42', offline: '#80848e' };
  const statusLabels = { online: 'Online', idle: 'Idle', dnd: 'Do Not Disturb', offline: 'Invisible' };

  const setStatus = (status) => {
    const socket = getSocket();
    if (socket) socket.emit('status:update', { status, custom_status: user.custom_status });
    api.patch('/users/me', { status }).then(setUser).catch(() => {});
    setShowMenu(false);
  };

  return (
    <div style={{ padding: '8px', background: '#232428', borderTop: '1px solid #1e1f22', position: 'relative' }}>
      <div
        onClick={() => setShowMenu(!showMenu)}
        style={{
          display: 'flex', alignItems: 'center', gap: 8, padding: '6px 8px', borderRadius: 4,
          cursor: 'pointer', userSelect: 'none'
        }}
        onMouseEnter={e => e.currentTarget.style.background = 'rgba(255,255,255,0.06)'}
        onMouseLeave={e => e.currentTarget.style.background = 'transparent'}
      >
        {/* Avatar */}
        <div style={{ position: 'relative', flexShrink: 0 }}>
          <div style={{
            width: 32, height: 32, borderRadius: '50%', background: user.accent_color || '#5865f2',
            display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 14, fontWeight: 700, color: '#fff', overflow: 'hidden'
          }}>
            {user.avatar ? <img src={user.avatar} alt="" style={{ width: '100%', height: '100%', objectFit: 'cover' }} /> : user.username[0].toUpperCase()}
          </div>
          <div style={{
            position: 'absolute', bottom: -1, right: -1, width: 12, height: 12, borderRadius: '50%',
            background: statusColor[user.status] || '#23a559', border: '2px solid #232428'
          }} />
        </div>

        {/* Info */}
        <div style={{ flex: 1, overflow: 'hidden' }}>
          <div style={{ fontSize: 13, fontWeight: 600, color: '#f2f3f5', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
            {user.username}
            {user.nitro && <span style={{ marginLeft: 4, fontSize: 10, color: '#ff73fa' }}>✦</span>}
          </div>
          <div style={{ fontSize: 11, color: '#80848e', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
            {user.custom_status || `#${user.discriminator}`}
          </div>
        </div>

        {/* Icons */}
        <div style={{ display: 'flex', gap: 4 }}>
          <IconBtn title="Mute" emoji="🎤" />
          <IconBtn title="Settings" emoji="⚙️" onClick={() => useStore.getState().setModal('settings')} />
        </div>
      </div>

      {showMenu && (
        <div style={{
          position: 'absolute', bottom: '100%', left: 8, right: 8, background: '#111214',
          borderRadius: 8, padding: 8, boxShadow: '0 8px 32px rgba(0,0,0,0.5)', zIndex: 100
        }}>
          <MenuSection label="Set Status">
            {Object.entries(statusLabels).map(([s, label]) => (
              <MenuItem key={s} label={label} icon={<div style={{ width: 10, height: 10, borderRadius: '50%', background: statusColor[s] }} />} onClick={() => setStatus(s)} />
            ))}
          </MenuSection>
          <div style={{ height: 1, background: '#35363c', margin: '4px 0' }} />
          <MenuItem label="Log Out" icon="🚪" onClick={() => { logout(); setShowMenu(false); }} danger />
        </div>
      )}
    </div>
  );
}

function IconBtn({ title, emoji, onClick }) {
  return (
    <div title={title} onClick={e => { e.stopPropagation(); onClick?.(); }} style={{
      width: 28, height: 28, borderRadius: 4, display: 'flex', alignItems: 'center', justifyContent: 'center',
      fontSize: 16, cursor: 'pointer', color: '#b5bac1'
    }}
      onMouseEnter={e => { e.currentTarget.style.background = 'rgba(255,255,255,0.1)'; e.currentTarget.style.color = '#dbdee1'; }}
      onMouseLeave={e => { e.currentTarget.style.background = 'transparent'; e.currentTarget.style.color = '#b5bac1'; }}
    >{emoji}</div>
  );
}

function MenuSection({ label, children }) {
  return (
    <div>
      <div style={{ fontSize: 11, fontWeight: 700, color: '#80848e', textTransform: 'uppercase', letterSpacing: 0.5, padding: '4px 8px 4px' }}>{label}</div>
      {children}
    </div>
  );
}

function MenuItem({ label, icon, onClick, danger }) {
  return (
    <div onClick={onClick} style={{
      display: 'flex', alignItems: 'center', gap: 8, padding: '6px 8px', borderRadius: 4,
      cursor: 'pointer', color: danger ? '#f23f42' : '#dbdee1', fontSize: 14
    }}
      onMouseEnter={e => { e.currentTarget.style.background = danger ? 'rgba(242,63,66,0.1)' : 'rgba(255,255,255,0.06)'; }}
      onMouseLeave={e => { e.currentTarget.style.background = 'transparent'; }}
    >
      <span style={{ fontSize: 16, display: 'flex', alignItems: 'center' }}>{icon}</span>
      {label}
    </div>
  );
}
