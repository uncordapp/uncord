import React from 'react';
import { useStore } from '../../store';

const STATUS_COLOR = { online: '#23a559', idle: '#f0b232', dnd: '#f23f42', offline: '#80848e', invisible: '#80848e' };

export default function MemberList() {
  const { activeServer, onlineUsers } = useStore();
  if (!activeServer) return null;

  const members = activeServer.members || [];
  const online = members.filter(m => {
    const s = onlineUsers[m.id]?.status || m.status;
    return s && s !== 'offline' && s !== 'invisible';
  });
  const offline = members.filter(m => {
    const s = onlineUsers[m.id]?.status || m.status;
    return !s || s === 'offline' || s === 'invisible';
  });

  return (
    <div style={{ width: 240, background: '#2b2d31', overflowY: 'auto', flexShrink: 0, padding: '16px 8px' }}>
      {online.length > 0 && (
        <MemberGroup label={`Online — ${online.length}`} members={online} onlineUsers={onlineUsers} />
      )}
      {offline.length > 0 && (
        <MemberGroup label={`Offline — ${offline.length}`} members={offline} onlineUsers={onlineUsers} />
      )}
    </div>
  );
}

function MemberGroup({ label, members, onlineUsers }) {
  return (
    <div style={{ marginBottom: 16 }}>
      <div style={{ fontSize: 11, fontWeight: 700, color: '#80848e', textTransform: 'uppercase', letterSpacing: 0.5, padding: '0 8px 4px' }}>
        {label}
      </div>
      {members.map(m => <MemberItem key={m.id} member={m} onlineUsers={onlineUsers} />)}
    </div>
  );
}

function MemberItem({ member, onlineUsers }) {
  const status = onlineUsers[member.id]?.status || member.status || 'offline';
  const badges = member.badges || [];

  return (
    <div style={{
      display: 'flex', alignItems: 'center', gap: 10, padding: '6px 8px', borderRadius: 4, cursor: 'pointer'
    }}
      onMouseEnter={e => e.currentTarget.style.background = 'rgba(255,255,255,0.06)'}
      onMouseLeave={e => e.currentTarget.style.background = 'transparent'}
    >
      <div style={{ position: 'relative', flexShrink: 0 }}>
        <div style={{
          width: 32, height: 32, borderRadius: '50%', background: '#5865f2',
          display: 'flex', alignItems: 'center', justifyContent: 'center', fontWeight: 700,
          color: '#fff', fontSize: 14, overflow: 'hidden',
          opacity: status === 'offline' ? 0.5 : 1
        }}>
          {member.avatar
            ? <img src={member.avatar} alt="" style={{ width: '100%', height: '100%', objectFit: 'cover' }} />
            : (member.username?.[0] || '?').toUpperCase()}
        </div>
        <div style={{
          position: 'absolute', bottom: -1, right: -1, width: 12, height: 12, borderRadius: '50%',
          background: STATUS_COLOR[status] || '#80848e', border: '2px solid #2b2d31'
        }} />
      </div>

      <div style={{ flex: 1, minWidth: 0 }}>
        <div style={{
          fontSize: 14, fontWeight: 500, color: member.platform_role === 'admin' ? '#f23f42' : '#dbdee1',
          opacity: status === 'offline' ? 0.5 : 1,
          overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap'
        }}>
          {member.nickname || member.username}
          {badges.includes('official') && <span style={{ marginLeft: 4, fontSize: 10 }}>✅</span>}
          {badges.includes('nitro') && <span style={{ marginLeft: 4, fontSize: 10, color: '#ff73fa' }}>✦</span>}
        </div>
        {onlineUsers[member.id]?.custom_status && (
          <div style={{ fontSize: 11, color: '#80848e', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>
            {onlineUsers[member.id].custom_status}
          </div>
        )}
      </div>
    </div>
  );
}
