import React from 'react';

const STATUS_COLOR = {
  online: '#23a559', idle: '#f0b232', dnd: '#f23f42',
  offline: '#80848e', invisible: '#80848e'
};

export default function Avatar({ user, size = 40, showStatus = false, status }) {
  const s = status || user?.status || 'offline';
  const initials = (user?.username?.[0] || '?').toUpperCase();
  const color = user?.accent_color || '#5865f2';

  return (
    <div style={{ position: 'relative', width: size, height: size, flexShrink: 0 }}>
      <div style={{
        width: size, height: size, borderRadius: '50%', background: color,
        display: 'flex', alignItems: 'center', justifyContent: 'center',
        fontWeight: 700, color: '#fff', fontSize: size * 0.38, overflow: 'hidden'
      }}>
        {user?.avatar
          ? <img src={user.avatar} alt="" style={{ width: '100%', height: '100%', objectFit: 'cover' }} />
          : initials}
      </div>
      {showStatus && (
        <div style={{
          position: 'absolute', bottom: -1, right: -1,
          width: size * 0.35, height: size * 0.35,
          borderRadius: '50%', background: STATUS_COLOR[s] || '#80848e',
          border: `2px solid #2b2d31`
        }} />
      )}
    </div>
  );
}
