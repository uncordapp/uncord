import React, { useState, useEffect } from 'react';
import api from '../../utils/api';
import { useStore } from '../../store';

const TABS = ['Overview', 'Users', 'Servers', 'Official Account', 'Settings', 'Audit Log'];

const BADGES_LIST = [
  { id: 'admin', label: 'Admin', icon: '🛡️', color: '#f23f42' },
  { id: 'staff', label: 'Staff', icon: '⚒️', color: '#5865f2' },
  { id: 'official', label: 'Official', icon: '✅', color: '#5865f2' },
  { id: 'verified', label: 'Verified', icon: '☑️', color: '#5865f2' },
  { id: 'nitro', label: 'Nitro', icon: '✦', color: '#ff73fa' },
  { id: 'partner', label: 'Partner', icon: '🤝', color: '#7289da' },
  { id: 'mod', label: 'Moderator', icon: '🔨', color: '#f0b232' },
  { id: 'bot', label: 'Bot', icon: '🤖', color: '#5865f2' },
  { id: 'early', label: 'Early Supporter', icon: '🌟', color: '#ff73fa' },
  { id: 'dev', label: 'Developer', icon: '💻', color: '#23a559' },
];

export default function AdminPanel({ onClose }) {
  const [tab, setTab] = useState('Overview');

  return (
    <div style={{ display: 'flex', height: '100vh', background: '#1e1f22' }}>
      {/* Sidebar */}
      <div style={{ width: 220, background: '#111214', display: 'flex', flexDirection: 'column', padding: '24px 8px' }}>
        <div style={{ padding: '0 12px 20px', borderBottom: '1px solid #2b2d31' }}>
          <div style={{ fontSize: 18, fontWeight: 800, color: '#5865f2', letterSpacing: -0.5 }}>⚙️ Admin Panel</div>
          <div style={{ fontSize: 11, color: '#80848e', marginTop: 2 }}>UnCord Control Center</div>
        </div>
        <div style={{ flex: 1, marginTop: 12 }}>
          {TABS.map(t => (
            <div key={t} onClick={() => setTab(t)} style={{
              padding: '10px 12px', borderRadius: 6, cursor: 'pointer', marginBottom: 2,
              color: tab === t ? '#fff' : '#80848e',
              background: tab === t ? '#5865f2' : 'transparent',
              fontWeight: tab === t ? 600 : 400, fontSize: 14
            }}
              onMouseEnter={e => { if (tab !== t) e.currentTarget.style.background = 'rgba(255,255,255,0.05)'; }}
              onMouseLeave={e => { if (tab !== t) e.currentTarget.style.background = 'transparent'; }}
            >
              {t}
            </div>
          ))}
        </div>
        <button onClick={onClose} style={{
          margin: 8, padding: '10px', background: '#313338', border: 'none', borderRadius: 6,
          color: '#b5bac1', cursor: 'pointer', fontSize: 14, fontWeight: 600
        }}>← Back to UnCord</button>
      </div>

      {/* Content */}
      <div style={{ flex: 1, overflowY: 'auto', padding: 32 }}>
        {tab === 'Overview' && <OverviewTab />}
        {tab === 'Users' && <UsersTab />}
        {tab === 'Servers' && <ServersTab />}
        {tab === 'Official Account' && <OfficialAccountTab />}
        {tab === 'Settings' && <SettingsTab />}
        {tab === 'Audit Log' && <AuditLogTab />}
      </div>
    </div>
  );
}

// ── Overview ──────────────────────────────────────────────
function OverviewTab() {
  const [stats, setStats] = useState(null);
  useEffect(() => { api.get('/admin/stats').then(setStats).catch(() => {}); }, []);

  return (
    <div>
      <PageTitle title="Overview" desc="Platform statistics at a glance" />
      {stats ? (
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(200px, 1fr))', gap: 16 }}>
          <StatCard icon="👥" label="Total Users" value={stats.users} color="#5865f2" />
          <StatCard icon="🌐" label="Servers" value={stats.servers} color="#23a559" />
          <StatCard icon="💬" label="Messages" value={stats.messages.toLocaleString()} color="#00a8fc" />
          <StatCard icon="🟢" label="Online Now" value={stats.online} color="#23a559" />
          <StatCard icon="🔨" label="Banned Users" value={stats.banned} color="#f23f42" />
        </div>
      ) : <Spinner />}
    </div>
  );
}

// ── Users ─────────────────────────────────────────────────
function UsersTab() {
  const [users, setUsers] = useState([]);
  const [total, setTotal] = useState(0);
  const [search, setSearch] = useState('');
  const [selected, setSelected] = useState(null);
  const [loading, setLoading] = useState(false);

  const load = (q = '') => {
    setLoading(true);
    api.get(`/admin/users?search=${q}&limit=50`)
      .then(d => { setUsers(d.users); setTotal(d.total); })
      .catch(() => {})
      .finally(() => setLoading(false));
  };

  useEffect(() => { load(); }, []);

  const handleSearch = (e) => {
    setSearch(e.target.value);
    clearTimeout(window._st);
    window._st = setTimeout(() => load(e.target.value), 400);
  };

  return (
    <div style={{ display: 'flex', gap: 24, height: 'calc(100vh - 64px)' }}>
      {/* List */}
      <div style={{ flex: 1, display: 'flex', flexDirection: 'column', minWidth: 0 }}>
        <PageTitle title={`Users (${total})`} desc="Manage all registered users" />
        <SearchBar value={search} onChange={handleSearch} placeholder="Search users..." />
        <div style={{ flex: 1, overflowY: 'auto', marginTop: 12 }}>
          {loading ? <Spinner /> : users.map(u => (
            <UserRow key={u.id} user={u} selected={selected?.id === u.id} onClick={() => setSelected(u)} />
          ))}
        </div>
      </div>

      {/* Editor */}
      {selected && (
        <UserEditor key={selected.id} user={selected} onClose={() => setSelected(null)} onSave={(updated) => {
          setUsers(us => us.map(u => u.id === updated.id ? updated : u));
          setSelected(updated);
        }} />
      )}
    </div>
  );
}

function UserRow({ user, selected, onClick }) {
  return (
    <div onClick={onClick} style={{
      display: 'flex', alignItems: 'center', gap: 12, padding: '10px 12px', borderRadius: 8,
      cursor: 'pointer', marginBottom: 4,
      background: selected ? 'rgba(88,101,242,0.2)' : 'transparent',
      border: selected ? '1px solid rgba(88,101,242,0.4)' : '1px solid transparent'
    }}
      onMouseEnter={e => { if (!selected) e.currentTarget.style.background = 'rgba(255,255,255,0.04)'; }}
      onMouseLeave={e => { if (!selected) e.currentTarget.style.background = 'transparent'; }}
    >
      <div style={{ width: 36, height: 36, borderRadius: '50%', background: user.accent_color || '#5865f2', display: 'flex', alignItems: 'center', justifyContent: 'center', fontWeight: 700, color: '#fff', fontSize: 14, overflow: 'hidden', flexShrink: 0 }}>
        {user.avatar ? <img src={user.avatar} alt="" style={{ width: '100%', height: '100%', objectFit: 'cover' }} /> : user.username[0].toUpperCase()}
      </div>
      <div style={{ flex: 1, minWidth: 0 }}>
        <div style={{ fontSize: 14, fontWeight: 600, color: '#f2f3f5', display: 'flex', alignItems: 'center', gap: 6 }}>
          {user.username}#{user.discriminator}
          {user.role === 'admin' && <Badge text="ADMIN" color="#f23f42" />}
          {user.banned && <Badge text="BANNED" color="#f23f42" />}
          {user.nitro && <Badge text="NITRO" color="#ff73fa" />}
        </div>
        <div style={{ fontSize: 12, color: '#80848e', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{user.email}</div>
      </div>
      <div style={{ fontSize: 11, color: user.account_standing === 'good' ? '#23a559' : '#f23f42', fontWeight: 700, textTransform: 'uppercase', flexShrink: 0 }}>
        {user.account_standing}
      </div>
    </div>
  );
}

function UserEditor({ user, onClose, onSave }) {
  const [form, setForm] = useState({
    username: user.username, email: user.email, discriminator: user.discriminator,
    bio: user.bio || '', status: user.status || 'online', custom_status: user.custom_status || '',
    role: user.role, account_standing: user.account_standing, nitro: user.nitro,
    badges: user.badges || [], accent_color: user.accent_color || '#5865f2',
    pronouns: user.pronouns || '', avatar: user.avatar || '', banner: user.banner || '',
    banned: user.banned || 0, ban_reason: user.ban_reason || '', password: ''
  });
  const [saving, setSaving] = useState(false);
  const [msg, setMsg] = useState('');

  const save = async () => {
    setSaving(true); setMsg('');
    try {
      const body = { ...form };
      if (!body.password) delete body.password;
      body.nitro = body.nitro ? 1 : 0;
      body.banned = body.banned ? 1 : 0;
      const updated = await api.patch(`/admin/users/${user.id}`, body);
      setMsg('✅ Saved!');
      onSave(updated);
    } catch (e) { setMsg('❌ ' + (e.error || 'Error')); }
    setSaving(false);
  };

  const toggleBadge = (badgeId) => {
    setForm(f => ({
      ...f, badges: f.badges.includes(badgeId) ? f.badges.filter(b => b !== badgeId) : [...f.badges, badgeId]
    }));
  };

  return (
    <div style={{ width: 360, background: '#2b2d31', borderRadius: 12, padding: 20, overflowY: 'auto', flexShrink: 0, border: '1px solid #35363c' }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 16 }}>
        <div style={{ fontWeight: 700, fontSize: 16, color: '#f2f3f5' }}>Edit User</div>
        <button onClick={onClose} style={{ background: 'none', border: 'none', color: '#80848e', cursor: 'pointer', fontSize: 20 }}>×</button>
      </div>

      <Section title="Identity">
        <Field label="Username" value={form.username} onChange={v => setForm(f => ({ ...f, username: v }))} />
        <Field label="Discriminator" value={form.discriminator} onChange={v => setForm(f => ({ ...f, discriminator: v }))} />
        <Field label="Email" value={form.email} onChange={v => setForm(f => ({ ...f, email: v }))} />
        <Field label="New Password" type="password" value={form.password} onChange={v => setForm(f => ({ ...f, password: v }))} placeholder="Leave blank to keep" />
      </Section>

      <Section title="Profile">
        <Field label="Bio" value={form.bio} onChange={v => setForm(f => ({ ...f, bio: v }))} multiline />
        <Field label="Pronouns" value={form.pronouns} onChange={v => setForm(f => ({ ...f, pronouns: v }))} placeholder="they/them" />
        <Field label="Accent Color" type="color" value={form.accent_color} onChange={v => setForm(f => ({ ...f, accent_color: v }))} />
        <Field label="Avatar URL" value={form.avatar} onChange={v => setForm(f => ({ ...f, avatar: v }))} placeholder="https://..." />
        <Field label="Banner URL" value={form.banner} onChange={v => setForm(f => ({ ...f, banner: v }))} placeholder="https://..." />
        <Field label="Custom Status" value={form.custom_status} onChange={v => setForm(f => ({ ...f, custom_status: v }))} />
      </Section>

      <Section title="Roles & Standing">
        <SelectField label="Platform Role" value={form.role} onChange={v => setForm(f => ({ ...f, role: v }))}
          options={[{ value: 'user', label: 'User' }, { value: 'admin', label: 'Admin' }]} />
        <SelectField label="Account Standing" value={form.account_standing} onChange={v => setForm(f => ({ ...f, account_standing: v }))}
          options={[{ value: 'good', label: '✅ Good' }, { value: 'warning', label: '⚠️ Warning' }, { value: 'suspended', label: '🚫 Suspended' }]} />
        <SelectField label="Status" value={form.status} onChange={v => setForm(f => ({ ...f, status: v }))}
          options={['online', 'idle', 'dnd', 'offline'].map(s => ({ value: s, label: s }))} />
        <ToggleField label="Nitro" value={form.nitro} onChange={v => setForm(f => ({ ...f, nitro: v }))} />
      </Section>

      <Section title="Badges">
        <div style={{ display: 'flex', flexWrap: 'wrap', gap: 6 }}>
          {BADGES_LIST.map(b => (
            <button key={b.id} onClick={() => toggleBadge(b.id)} style={{
              padding: '4px 10px', borderRadius: 12, fontSize: 12, cursor: 'pointer', fontWeight: 600,
              background: form.badges.includes(b.id) ? b.color : 'rgba(255,255,255,0.06)',
              color: form.badges.includes(b.id) ? '#fff' : '#b5bac1',
              border: `1px solid ${form.badges.includes(b.id) ? b.color : 'transparent'}`
            }}>
              {b.icon} {b.label}
            </button>
          ))}
        </div>
      </Section>

      <Section title="Ban">
        <ToggleField label="Banned" value={form.banned} onChange={v => setForm(f => ({ ...f, banned: v }))} danger />
        {form.banned ? <Field label="Ban Reason" value={form.ban_reason} onChange={v => setForm(f => ({ ...f, ban_reason: v }))} /> : null}
      </Section>

      {msg && <div style={{ fontSize: 13, color: msg.startsWith('✅') ? '#23a559' : '#f23f42', marginBottom: 8 }}>{msg}</div>}

      <button onClick={save} disabled={saving} style={{
        width: '100%', padding: '10px', background: '#5865f2', color: '#fff', border: 'none',
        borderRadius: 6, cursor: 'pointer', fontWeight: 700, fontSize: 14, opacity: saving ? 0.7 : 1
      }}>
        {saving ? 'Saving...' : '💾 Save Changes'}
      </button>
    </div>
  );
}

// ── Servers ───────────────────────────────────────────────
function ServersTab() {
  const [servers, setServers] = useState([]);
  const [selected, setSelected] = useState(null);
  const [search, setSearch] = useState('');

  const load = (q = '') => {
    api.get(`/admin/servers?search=${q}&limit=100`).then(d => setServers(d.servers)).catch(() => {});
  };

  useEffect(() => { load(); }, []);

  const handleSearch = (e) => {
    setSearch(e.target.value);
    clearTimeout(window._ss);
    window._ss = setTimeout(() => load(e.target.value), 400);
  };

  return (
    <div style={{ display: 'flex', gap: 24, height: 'calc(100vh - 64px)' }}>
      <div style={{ flex: 1, display: 'flex', flexDirection: 'column', minWidth: 0 }}>
        <PageTitle title={`Servers (${servers.length})`} desc="Manage all servers" />
        <SearchBar value={search} onChange={handleSearch} placeholder="Search servers..." />
        <div style={{ flex: 1, overflowY: 'auto', marginTop: 12 }}>
          {servers.map(s => (
            <div key={s.id} onClick={() => setSelected(s)} style={{
              display: 'flex', alignItems: 'center', gap: 12, padding: '10px 12px', borderRadius: 8,
              cursor: 'pointer', marginBottom: 4,
              background: selected?.id === s.id ? 'rgba(88,101,242,0.2)' : 'transparent',
              border: selected?.id === s.id ? '1px solid rgba(88,101,242,0.4)' : '1px solid transparent'
            }}
              onMouseEnter={e => { if (selected?.id !== s.id) e.currentTarget.style.background = 'rgba(255,255,255,0.04)'; }}
              onMouseLeave={e => { if (selected?.id !== s.id) e.currentTarget.style.background = 'transparent'; }}
            >
              <div style={{ width: 36, height: 36, borderRadius: 12, background: '#5865f2', display: 'flex', alignItems: 'center', justifyContent: 'center', fontWeight: 700, color: '#fff', fontSize: 14, overflow: 'hidden', flexShrink: 0 }}>
                {s.icon ? <img src={s.icon} alt="" style={{ width: '100%', height: '100%', objectFit: 'cover' }} /> : s.name[0].toUpperCase()}
              </div>
              <div style={{ flex: 1, minWidth: 0 }}>
                <div style={{ fontSize: 14, fontWeight: 600, color: '#f2f3f5', display: 'flex', alignItems: 'center', gap: 6 }}>
                  {s.name}
                  {s.server_tag && <Badge text={s.server_tag} color="#5865f2" />}
                  {s.verified && <Badge text="✅ Verified" color="#23a559" />}
                </div>
                <div style={{ fontSize: 12, color: '#80848e' }}>Boost Lv.{s.boost_level} • {s.boosts} boosts</div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {selected && (
        <ServerEditor key={selected.id} server={selected} onClose={() => setSelected(null)} onSave={updated => {
          setServers(ss => ss.map(s => s.id === updated.id ? updated : s));
          setSelected(updated);
        }} />
      )}
    </div>
  );
}

function ServerEditor({ server, onClose, onSave }) {
  const ALL_FEATURES = ['COMMUNITY','NEWS','DISCOVERABLE','VERIFIED','PARTNERED','VANITY_URL',
    'INVITE_SPLASH','BANNER','ANIMATED_ICON','ANIMATED_BANNER','MEMBER_PROFILES','ROLE_ICONS',
    'AUTO_MODERATION','MONETIZATION_ENABLED','MORE_STICKERS','THREADS_ENABLED','PRIVATE_THREADS'];

  const [form, setForm] = useState({
    name: server.name, description: server.description || '',
    server_tag: server.server_tag || '', community: server.community || 0,
    verified: server.verified || 0, partnered: server.partnered || 0,
    boosts: server.boosts || 999, boost_level: server.boost_level || 3,
    features: server.features || [], invite_code: server.invite_code || '',
    icon: server.icon || '', banner: server.banner || ''
  });
  const [saving, setSaving] = useState(false);
  const [msg, setMsg] = useState('');
  const [deleting, setDeleting] = useState(false);

  const save = async () => {
    setSaving(true); setMsg('');
    try {
      const updated = await api.patch(`/admin/servers/${server.id}`, form);
      setMsg('✅ Saved!'); onSave(updated);
    } catch (e) { setMsg('❌ ' + (e.error || 'Error')); }
    setSaving(false);
  };

  const deleteServer = async () => {
    if (!window.confirm('Delete this server? This cannot be undone.')) return;
    await api.delete(`/admin/servers/${server.id}`);
    onClose();
  };

  const toggleFeature = (f) => {
    setForm(prev => ({
      ...prev,
      features: prev.features.includes(f) ? prev.features.filter(x => x !== f) : [...prev.features, f]
    }));
  };

  return (
    <div style={{ width: 380, background: '#2b2d31', borderRadius: 12, padding: 20, overflowY: 'auto', flexShrink: 0, border: '1px solid #35363c' }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 16 }}>
        <div style={{ fontWeight: 700, fontSize: 16, color: '#f2f3f5' }}>Edit Server</div>
        <button onClick={onClose} style={{ background: 'none', border: 'none', color: '#80848e', cursor: 'pointer', fontSize: 20 }}>×</button>
      </div>

      <Section title="Basic Info">
        <Field label="Name" value={form.name} onChange={v => setForm(f => ({ ...f, name: v }))} />
        <Field label="Description" value={form.description} onChange={v => setForm(f => ({ ...f, description: v }))} multiline />
        <Field label="Server Tag" value={form.server_tag} onChange={v => setForm(f => ({ ...f, server_tag: v }))} placeholder="Any length tag!" />
        <Field label="Invite Code" value={form.invite_code} onChange={v => setForm(f => ({ ...f, invite_code: v }))} />
        <Field label="Icon URL" value={form.icon} onChange={v => setForm(f => ({ ...f, icon: v }))} />
        <Field label="Banner URL" value={form.banner} onChange={v => setForm(f => ({ ...f, banner: v }))} />
      </Section>

      <Section title="Boosts & Level">
        <div style={{ display: 'flex', gap: 12 }}>
          <Field label="Boost Count" type="number" value={form.boosts} onChange={v => setForm(f => ({ ...f, boosts: parseInt(v) }))} />
          <SelectField label="Boost Level" value={form.boost_level} onChange={v => setForm(f => ({ ...f, boost_level: parseInt(v) }))}
            options={[0,1,2,3].map(n => ({ value: n, label: `Level ${n}` }))} />
        </div>
      </Section>

      <Section title="Flags">
        <div style={{ display: 'flex', gap: 12, flexWrap: 'wrap' }}>
          <ToggleField label="Community" value={form.community} onChange={v => setForm(f => ({ ...f, community: v }))} />
          <ToggleField label="Verified" value={form.verified} onChange={v => setForm(f => ({ ...f, verified: v }))} />
          <ToggleField label="Partnered" value={form.partnered} onChange={v => setForm(f => ({ ...f, partnered: v }))} />
        </div>
      </Section>

      <Section title="Features">
        <div style={{ display: 'flex', flexWrap: 'wrap', gap: 6 }}>
          {ALL_FEATURES.map(f => (
            <button key={f} onClick={() => toggleFeature(f)} style={{
              padding: '3px 8px', borderRadius: 10, fontSize: 11, cursor: 'pointer', fontWeight: 600,
              background: form.features.includes(f) ? '#5865f2' : 'rgba(255,255,255,0.06)',
              color: form.features.includes(f) ? '#fff' : '#b5bac1',
              border: `1px solid ${form.features.includes(f) ? '#5865f2' : 'transparent'}`
            }}>{f}</button>
          ))}
          <button onClick={() => setForm(f => ({ ...f, features: ALL_FEATURES }))} style={{
            padding: '3px 8px', borderRadius: 10, fontSize: 11, cursor: 'pointer',
            background: '#23a559', color: '#fff', border: 'none', fontWeight: 700
          }}>All</button>
        </div>
      </Section>

      {msg && <div style={{ fontSize: 13, color: msg.startsWith('✅') ? '#23a559' : '#f23f42', marginBottom: 8 }}>{msg}</div>}

      <div style={{ display: 'flex', gap: 8 }}>
        <button onClick={save} disabled={saving} style={{
          flex: 1, padding: '10px', background: '#5865f2', color: '#fff', border: 'none',
          borderRadius: 6, cursor: 'pointer', fontWeight: 700, fontSize: 14
        }}>
          {saving ? 'Saving...' : '💾 Save'}
        </button>
        <button onClick={deleteServer} style={{
          padding: '10px 14px', background: 'rgba(242,63,66,0.15)', color: '#f23f42', border: '1px solid rgba(242,63,66,0.3)',
          borderRadius: 6, cursor: 'pointer', fontWeight: 700, fontSize: 14
        }}>🗑️</button>
      </div>
    </div>
  );
}

// ── Official Account ──────────────────────────────────────
function OfficialAccountTab() {
  const [account, setAccount] = useState(null);
  const [channels, setChannels] = useState([]);
  const [form, setForm] = useState({ username: 'UnCord', bio: 'The official UnCord account.' });
  const [msgForm, setMsgForm] = useState({ channel_id: '', content: '' });
  const [status, setStatus] = useState('');

  useEffect(() => {
    api.get('/admin/settings').then(s => {
      if (s.official_account_id) setAccount({ id: s.official_account_id });
    }).catch(() => {});
    // Get all channels across all servers
    api.get('/servers/me').then(async servers => {
      const allChannels = [];
      for (const sv of servers) {
        try {
          const full = await api.get(`/servers/${sv.id}`);
          for (const ch of full.channels || []) {
            if (ch.type === 'text') allChannels.push({ ...ch, serverName: sv.name });
          }
        } catch {}
      }
      setChannels(allChannels);
    }).catch(() => {});
  }, []);

  const createOrUpdate = async () => {
    try {
      const res = await api.post('/admin/official-account', form);
      setAccount(res); setStatus('✅ Official account ready!');
    } catch (e) { setStatus('❌ ' + (e.error || 'Error')); }
  };

  const sendMsg = async () => {
    if (!msgForm.channel_id || !msgForm.content.trim()) return;
    try {
      await api.post('/admin/official-account/send', msgForm);
      setStatus('✅ Message sent!'); setMsgForm(f => ({ ...f, content: '' }));
    } catch (e) { setStatus('❌ ' + (e.error || 'Error')); }
  };

  return (
    <div style={{ maxWidth: 640 }}>
      <PageTitle title="Official Account" desc="Manage the platform official account and send announcements" />

      <Card>
        <SectionTitle>Account Setup</SectionTitle>
        {account && <div style={{ marginBottom: 12, padding: '8px 12px', background: 'rgba(35,165,89,0.15)', borderRadius: 6, color: '#23a559', fontSize: 13 }}>
          ✅ Official account exists (ID: {account.id})
        </div>}
        <Field label="Username" value={form.username} onChange={v => setForm(f => ({ ...f, username: v }))} />
        <Field label="Bio" value={form.bio} onChange={v => setForm(f => ({ ...f, bio: v }))} multiline />
        <button onClick={createOrUpdate} style={{ marginTop: 8, padding: '10px 20px', background: '#5865f2', color: '#fff', border: 'none', borderRadius: 6, cursor: 'pointer', fontWeight: 700 }}>
          {account ? '🔄 Update Account' : '✨ Create Official Account'}
        </button>
      </Card>

      {account && (
        <Card style={{ marginTop: 16 }}>
          <SectionTitle>Send Message as Official Account</SectionTitle>
          <div style={{ marginBottom: 12 }}>
            <label style={labelStyle}>Target Channel</label>
            <select value={msgForm.channel_id} onChange={e => setMsgForm(f => ({ ...f, channel_id: e.target.value }))} style={selectStyle}>
              <option value="">Select a channel...</option>
              {channels.map(ch => (
                <option key={ch.id} value={ch.id}>{ch.serverName} › #{ch.name}</option>
              ))}
            </select>
          </div>
          <Field label="Message" value={msgForm.content} onChange={v => setMsgForm(f => ({ ...f, content: v }))} multiline placeholder="Type your announcement..." />
          <button onClick={sendMsg} style={{ marginTop: 8, padding: '10px 20px', background: '#5865f2', color: '#fff', border: 'none', borderRadius: 6, cursor: 'pointer', fontWeight: 700 }}>
            📢 Send Announcement
          </button>
        </Card>
      )}

      {status && <div style={{ marginTop: 12, fontSize: 13, color: status.startsWith('✅') ? '#23a559' : '#f23f42' }}>{status}</div>}
    </div>
  );
}

// ── Platform Settings ─────────────────────────────────────
function SettingsTab() {
  const { setUser, user } = useStore();
  const [settings, setSettings] = useState(null);
  const [form, setForm] = useState({});
  const [msg, setMsg] = useState('');

  useEffect(() => {
    api.get('/admin/settings').then(s => { setSettings(s); setForm(s); }).catch(() => {});
  }, []);

  const save = async () => {
    try {
      await api.patch('/admin/settings', form);
      setMsg('✅ Settings saved!');
    } catch (e) { setMsg('❌ ' + (e.error || 'Error')); }
  };

  const grantAllNitro = async () => {
    await api.post('/admin/users/nitro/all');
    setMsg('✅ Granted Nitro to all users!');
  };

  if (!settings) return <Spinner />;

  return (
    <div style={{ maxWidth: 640 }}>
      <PageTitle title="Platform Settings" desc="Configure global platform behavior" />

      <Card>
        <SectionTitle>General</SectionTitle>
        <Field label="Platform Name" value={form.platform_name || ''} onChange={v => setForm(f => ({ ...f, platform_name: v }))} />
        <Field label="Platform Description" value={form.platform_description || ''} onChange={v => setForm(f => ({ ...f, platform_description: v }))} multiline />
        <Field label="Max Message Length" type="number" value={form.max_message_length || '4000'} onChange={v => setForm(f => ({ ...f, max_message_length: v }))} />
        <Field label="Max Servers Per User" type="number" value={form.max_servers_per_user || '100'} onChange={v => setForm(f => ({ ...f, max_servers_per_user: v }))} />
        <ToggleField label="Allow Registration" value={form.allow_registration === 'true'} onChange={v => setForm(f => ({ ...f, allow_registration: v ? 'true' : 'false' }))} />
        <button onClick={save} style={{ marginTop: 12, padding: '10px 20px', background: '#5865f2', color: '#fff', border: 'none', borderRadius: 6, cursor: 'pointer', fontWeight: 700 }}>
          💾 Save Settings
        </button>
      </Card>

      <Card style={{ marginTop: 16 }}>
        <SectionTitle>Mass Actions</SectionTitle>
        <div style={{ display: 'flex', gap: 12, flexWrap: 'wrap' }}>
          <ActionButton label="✦ Grant Nitro to All Users" color="#ff73fa" onClick={grantAllNitro} confirm="Grant Nitro to ALL users?" />
        </div>
      </Card>

      {msg && <div style={{ marginTop: 12, fontSize: 13, color: msg.startsWith('✅') ? '#23a559' : '#f23f42' }}>{msg}</div>}
    </div>
  );
}

// ── Audit Log ─────────────────────────────────────────────
function AuditLogTab() {
  const [logs, setLogs] = useState([]);
  useEffect(() => { api.get('/admin/audit-log').then(setLogs).catch(() => {}); }, []);

  return (
    <div>
      <PageTitle title="Audit Log" desc="Recent admin actions" />
      <div style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>
        {logs.map(log => (
          <div key={log.id} style={{ background: '#2b2d31', borderRadius: 8, padding: '10px 14px', border: '1px solid #35363c' }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 4 }}>
              <span style={{ fontSize: 13, fontWeight: 700, color: '#f2f3f5' }}>{log.action}</span>
              <span style={{ fontSize: 12, color: '#80848e' }}>{new Date(log.created_at * 1000).toLocaleString()}</span>
            </div>
            <div style={{ fontSize: 12, color: '#80848e' }}>
              By <strong style={{ color: '#b5bac1' }}>{log.admin_username}</strong>
              {log.target_type && <> on <strong style={{ color: '#b5bac1' }}>{log.target_type}</strong></>}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

// ── Reusable components ───────────────────────────────────
const labelStyle = { display: 'block', color: '#b5bac1', fontSize: 11, fontWeight: 700, textTransform: 'uppercase', letterSpacing: 0.5, marginBottom: 6 };
const inputStyle = { width: '100%', padding: '8px 10px', background: '#1e1f22', border: '1px solid #35363c', borderRadius: 6, color: '#dbdee1', fontSize: 14, outline: 'none', fontFamily: 'inherit' };
const selectStyle = { ...inputStyle, cursor: 'pointer' };

function Field({ label, type = 'text', value, onChange, placeholder, multiline }) {
  return (
    <div style={{ marginBottom: 12 }}>
      {label && <label style={labelStyle}>{label}</label>}
      {multiline ? (
        <textarea value={value} onChange={e => onChange(e.target.value)} placeholder={placeholder}
          rows={3} style={{ ...inputStyle, resize: 'vertical' }} />
      ) : (
        <input type={type} value={value} onChange={e => onChange(e.target.value)} placeholder={placeholder} style={inputStyle} />
      )}
    </div>
  );
}

function SelectField({ label, value, onChange, options }) {
  return (
    <div style={{ marginBottom: 12 }}>
      {label && <label style={labelStyle}>{label}</label>}
      <select value={value} onChange={e => onChange(e.target.value)} style={selectStyle}>
        {options.map(o => <option key={o.value} value={o.value}>{o.label}</option>)}
      </select>
    </div>
  );
}

function ToggleField({ label, value, onChange, danger }) {
  return (
    <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 12 }}>
      <span style={{ fontSize: 13, color: danger ? '#f23f42' : '#b5bac1', fontWeight: 600 }}>{label}</span>
      <div onClick={() => onChange(!value)} style={{
        width: 44, height: 24, borderRadius: 12, background: value ? (danger ? '#f23f42' : '#5865f2') : '#35363c',
        cursor: 'pointer', position: 'relative', transition: 'background 0.2s'
      }}>
        <div style={{
          position: 'absolute', top: 3, left: value ? 23 : 3, width: 18, height: 18,
          borderRadius: '50%', background: '#fff', transition: 'left 0.2s'
        }} />
      </div>
    </div>
  );
}

function Section({ title, children }) {
  return (
    <div style={{ marginBottom: 20 }}>
      <div style={{ fontSize: 11, fontWeight: 700, color: '#5865f2', textTransform: 'uppercase', letterSpacing: 0.5, marginBottom: 10, paddingBottom: 6, borderBottom: '1px solid #35363c' }}>{title}</div>
      {children}
    </div>
  );
}

function SectionTitle({ children }) {
  return <div style={{ fontSize: 14, fontWeight: 700, color: '#f2f3f5', marginBottom: 14 }}>{children}</div>;
}

function Card({ children, style }) {
  return <div style={{ background: '#2b2d31', borderRadius: 12, padding: 20, border: '1px solid #35363c', ...style }}>{children}</div>;
}

function PageTitle({ title, desc }) {
  return (
    <div style={{ marginBottom: 24 }}>
      <h1 style={{ fontSize: 22, fontWeight: 800, color: '#f2f3f5', margin: 0 }}>{title}</h1>
      {desc && <p style={{ fontSize: 14, color: '#80848e', marginTop: 4 }}>{desc}</p>}
    </div>
  );
}

function SearchBar({ value, onChange, placeholder }) {
  return (
    <div style={{ display: 'flex', alignItems: 'center', background: '#1e1f22', borderRadius: 6, padding: '8px 12px', gap: 8, border: '1px solid #35363c' }}>
      <span style={{ color: '#80848e' }}>🔍</span>
      <input value={value} onChange={onChange} placeholder={placeholder} style={{ background: 'none', border: 'none', outline: 'none', color: '#dbdee1', fontSize: 14, flex: 1 }} />
    </div>
  );
}

function StatCard({ icon, label, value, color }) {
  return (
    <div style={{ background: '#2b2d31', borderRadius: 12, padding: 20, border: `1px solid ${color}33`, display: 'flex', alignItems: 'center', gap: 16 }}>
      <div style={{ width: 48, height: 48, borderRadius: 12, background: `${color}22`, display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 24 }}>{icon}</div>
      <div>
        <div style={{ fontSize: 28, fontWeight: 800, color }}>{value}</div>
        <div style={{ fontSize: 13, color: '#80848e' }}>{label}</div>
      </div>
    </div>
  );
}

function Badge({ text, color }) {
  return <span style={{ fontSize: 10, background: `${color}22`, color, border: `1px solid ${color}44`, borderRadius: 4, padding: '1px 5px', fontWeight: 700 }}>{text}</span>;
}

function Spinner() {
  return <div style={{ display: 'flex', justifyContent: 'center', padding: 32, color: '#80848e' }}>Loading...</div>;
}

function ActionButton({ label, color, onClick, confirm: confirmMsg }) {
  const handle = () => {
    if (confirmMsg && !window.confirm(confirmMsg)) return;
    onClick();
  };
  return (
    <button onClick={handle} style={{
      padding: '10px 16px', background: `${color}22`, color, border: `1px solid ${color}44`,
      borderRadius: 8, cursor: 'pointer', fontWeight: 700, fontSize: 13
    }}>{label}</button>
  );
}
