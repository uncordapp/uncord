import React, { useState, useEffect, useRef, useCallback } from 'react';
import { useStore } from '../../store';
import api, { getSocket } from '../../utils/api';
import MessageItem from './MessageItem';
import MessageInput from './MessageInput';

export default function ChatArea() {
  const { activeChannel, activeServer, messages, setMessages, prependMessages } = useStore();
  const bottomRef = useRef(null);
  const listRef = useRef(null);
  const [loading, setLoading] = useState(false);
  const [hasMore, setHasMore] = useState(true);
  const typingUsers = useStore(s => s.typing[activeChannel?.id] || []);

  const channelMsgs = messages[activeChannel?.id] || [];

  useEffect(() => {
    if (!activeChannel) return;
    setLoading(true);
    api.get(`/messages/channels/${activeChannel.id}`)
      .then(msgs => {
        setMessages(activeChannel.id, msgs);
        setHasMore(msgs.length === 50);
        setTimeout(() => bottomRef.current?.scrollIntoView({ behavior: 'auto' }), 50);
      })
      .catch(() => {})
      .finally(() => setLoading(false));
  }, [activeChannel?.id]);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [channelMsgs.length]);

  const loadMore = useCallback(async () => {
    if (!hasMore || loading || !channelMsgs.length) return;
    setLoading(true);
    try {
      const older = await api.get(`/messages/channels/${activeChannel.id}?before=${channelMsgs[0].id}&limit=50`);
      prependMessages(activeChannel.id, older);
      setHasMore(older.length === 50);
    } catch {}
    finally { setLoading(false); }
  }, [activeChannel?.id, hasMore, loading, channelMsgs]);

  const handleScroll = useCallback((e) => {
    if (e.target.scrollTop < 100) loadMore();
  }, [loadMore]);

  if (!activeChannel) return (
    <div style={{ flex: 1, display: 'flex', alignItems: 'center', justifyContent: 'center', color: '#80848e', fontSize: 18 }}>
      Select a channel
    </div>
  );

  return (
    <div style={{ flex: 1, display: 'flex', flexDirection: 'column', overflow: 'hidden', background: '#313338' }}>
      {/* Channel header */}
      <div style={{
        height: 48, padding: '0 16px', display: 'flex', alignItems: 'center', gap: 12,
        borderBottom: '1px solid #1e1f22', flexShrink: 0, background: '#313338',
        boxShadow: '0 1px 0 rgba(0,0,0,0.2)'
      }}>
        <span style={{ fontSize: 20, color: '#80848e' }}>#</span>
        <span style={{ fontWeight: 700, color: '#f2f3f5', fontSize: 15 }}>{activeChannel.name}</span>
        {activeChannel.topic && (
          <>
            <div style={{ width: 1, height: 24, background: '#35363c' }} />
            <span style={{ fontSize: 13, color: '#80848e', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{activeChannel.topic}</span>
          </>
        )}
      </div>

      {/* Messages */}
      <div ref={listRef} onScroll={handleScroll} style={{ flex: 1, overflowY: 'auto', padding: '16px 0', display: 'flex', flexDirection: 'column' }}>
        {loading && (
          <div style={{ textAlign: 'center', padding: 16, color: '#80848e', fontSize: 13 }}>Loading...</div>
        )}
        {!hasMore && channelMsgs.length > 0 && (
          <ChannelStart name={activeChannel.name} />
        )}
        {channelMsgs.map((msg, i) => (
          <MessageItem
            key={msg.id}
            message={msg}
            prevMessage={channelMsgs[i - 1]}
          />
        ))}
        {channelMsgs.length === 0 && !loading && (
          <ChannelStart name={activeChannel.name} />
        )}
        <div ref={bottomRef} />
      </div>

      {/* Typing indicator */}
      {typingUsers.length > 0 && (
        <div style={{ padding: '0 16px 4px', fontSize: 12, color: '#dbdee1', height: 24, flexShrink: 0 }}>
          <TypingDots />
          <span style={{ marginLeft: 6 }}>
            {typingUsers.map(u => <strong key={u.userId}>{u.username}</strong>).reduce((a, b) => [a, ', ', b])}
            {typingUsers.length === 1 ? ' is typing...' : ' are typing...'}
          </span>
        </div>
      )}

      {/* Input */}
      <MessageInput channelId={activeChannel.id} channelName={activeChannel.name} />
    </div>
  );
}

function ChannelStart({ name }) {
  return (
    <div style={{ padding: '16px 16px 24px' }}>
      <div style={{ width: 68, height: 68, borderRadius: '50%', background: '#35363c', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 32, marginBottom: 16 }}>
        #
      </div>
      <div style={{ fontSize: 28, fontWeight: 700, color: '#f2f3f5', marginBottom: 8 }}>Welcome to #{name}!</div>
      <div style={{ fontSize: 15, color: '#80848e' }}>This is the start of the #{name} channel.</div>
    </div>
  );
}

function TypingDots() {
  return (
    <span style={{ display: 'inline-flex', gap: 2, alignItems: 'center' }}>
      {[0, 1, 2].map(i => (
        <span key={i} style={{
          width: 6, height: 6, borderRadius: '50%', background: '#dbdee1', display: 'inline-block',
          animation: `pulse 1.2s ease-in-out ${i * 0.2}s infinite`
        }} />
      ))}
    </span>
  );
}
