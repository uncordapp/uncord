import React, { useEffect, useRef } from 'react';
import { useStore } from '../../store';
import api, { getSocket } from '../../utils/api';
import MessageItem from './MessageItem';
import MessageInput from './MessageInput';

export default function DMArea() {
  const { activeDM, messages, setMessages } = useStore();
  const bottomRef = useRef(null);
  const other = activeDM?.user;

  useEffect(() => {
    if (!other) return;
    api.get(`/messages/dm/${other.id}`).then(data => {
      setMessages(`dm:${other.id}`, data.messages || []);
      setTimeout(() => bottomRef.current?.scrollIntoView({ behavior: 'auto' }), 50);
    }).catch(() => {});
  }, [other?.id]);

  const channelMsgs = messages[`dm:${other?.id}`] || [];

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [channelMsgs.length]);

  if (!other) return null;

  return (
    <div style={{ flex: 1, display: 'flex', flexDirection: 'column', overflow: 'hidden', background: '#313338' }}>
      {/* Header */}
      <div style={{
        height: 48, padding: '0 16px', display: 'flex', alignItems: 'center', gap: 12,
        borderBottom: '1px solid #1e1f22', flexShrink: 0, boxShadow: '0 1px 0 rgba(0,0,0,0.2)'
      }}>
        <div style={{ width: 24, height: 24, borderRadius: '50%', background: '#5865f2', display: 'flex', alignItems: 'center', justifyContent: 'center', fontWeight: 700, color: '#fff', fontSize: 12, overflow: 'hidden' }}>
          {other.avatar ? <img src={other.avatar} alt="" style={{ width: '100%', height: '100%', objectFit: 'cover' }} /> : other.username[0].toUpperCase()}
        </div>
        <span style={{ fontWeight: 700, color: '#f2f3f5', fontSize: 15 }}>@{other.username}</span>
      </div>

      {/* Messages */}
      <div style={{ flex: 1, overflowY: 'auto', padding: '16px 0', display: 'flex', flexDirection: 'column' }}>
        {channelMsgs.length === 0 && (
          <div style={{ padding: 24 }}>
            <div style={{ fontSize: 28, fontWeight: 700, color: '#f2f3f5', marginBottom: 8 }}>@{other.username}</div>
            <div style={{ fontSize: 15, color: '#80848e' }}>This is the beginning of your direct message history with <strong>@{other.username}</strong>.</div>
          </div>
        )}
        {channelMsgs.map((msg, i) => (
          <MessageItem key={msg.id} message={msg} prevMessage={channelMsgs[i - 1]} />
        ))}
        <div ref={bottomRef} />
      </div>

      <DMMessageInput userId={other.id} username={other.username} />
    </div>
  );
}

function DMMessageInput({ userId, username }) {
  const [content, setContent] = React.useState('');
  const textareaRef = React.useRef(null);
  const socket = getSocket();

  const send = () => {
    if (!content.trim()) return;
    if (socket) socket.emit('dm:send', { to_user_id: userId, content: content.trim() });
    setContent('');
  };

  return (
    <div style={{ padding: '0 16px 20px', flexShrink: 0 }}>
      <div style={{ background: '#383a40', borderRadius: 8, display: 'flex', alignItems: 'flex-end', padding: '0 16px', gap: 12 }}>
        <textarea
          ref={textareaRef}
          value={content}
          onChange={e => setContent(e.target.value)}
          onKeyDown={e => { if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); send(); } }}
          placeholder={`Message @${username}`}
          rows={1}
          style={{
            flex: 1, background: 'transparent', border: 'none', outline: 'none', resize: 'none',
            color: '#dbdee1', fontSize: 15, lineHeight: 1.5, padding: '11px 0', fontFamily: 'inherit',
            maxHeight: 200, overflowY: 'auto'
          }}
        />
        {content.trim() && (
          <button onClick={send} style={{ background: '#5865f2', border: 'none', borderRadius: 4, color: '#fff', cursor: 'pointer', padding: '6px 10px', fontSize: 18, marginBottom: 8 }}>
            ➤
          </button>
        )}
      </div>
    </div>
  );
}
