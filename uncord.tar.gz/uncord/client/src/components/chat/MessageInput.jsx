import React, { useState, useRef, useEffect, useCallback } from 'react';
import { getSocket } from '../../utils/api';
import api from '../../utils/api';

export default function MessageInput({ channelId, channelName }) {
  const [content, setContent] = useState('');
  const [uploading, setUploading] = useState(false);
  const [pendingFiles, setPendingFiles] = useState([]);
  const textareaRef = useRef(null);
  const typingTimeout = useRef(null);
  const isTyping = useRef(false);

  useEffect(() => {
    textareaRef.current?.focus();
  }, [channelId]);

  const stopTyping = useCallback(() => {
    if (isTyping.current) {
      isTyping.current = false;
      const socket = getSocket();
      if (socket) socket.emit('typing:stop', { channel_id: channelId });
    }
  }, [channelId]);

  const handleChange = (e) => {
    setContent(e.target.value);
    const socket = getSocket();
    if (!socket) return;

    if (!isTyping.current) {
      isTyping.current = true;
      socket.emit('typing:start', { channel_id: channelId });
    }
    clearTimeout(typingTimeout.current);
    typingTimeout.current = setTimeout(stopTyping, 3000);

    // Auto-resize
    e.target.style.height = 'auto';
    e.target.style.height = Math.min(e.target.scrollHeight, 200) + 'px';
  };

  const send = useCallback(() => {
    const trimmed = content.trim();
    if (!trimmed && !pendingFiles.length) return;
    const socket = getSocket();
    if (socket) {
      socket.emit('message:send', { channel_id: channelId, content: trimmed, attachments: pendingFiles });
    }
    setContent('');
    setPendingFiles([]);
    stopTyping();
    if (textareaRef.current) {
      textareaRef.current.style.height = 'auto';
    }
  }, [content, channelId, pendingFiles, stopTyping]);

  const handleKeyDown = (e) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      send();
    }
  };

  const handleFileChange = async (e) => {
    const file = e.target.files[0];
    if (!file) return;
    setUploading(true);
    try {
      const form = new FormData();
      form.append('file', file);
      const res = await api.post('/upload', form, { headers: { 'Content-Type': 'multipart/form-data' } });
      setPendingFiles(f => [...f, { url: res.url, name: file.name }]);
    } catch {}
    setUploading(false);
    e.target.value = '';
  };

  return (
    <div style={{ padding: '0 16px 20px', flexShrink: 0 }}>
      {/* Pending files */}
      {pendingFiles.length > 0 && (
        <div style={{ display: 'flex', gap: 8, marginBottom: 8, flexWrap: 'wrap' }}>
          {pendingFiles.map((f, i) => (
            <div key={i} style={{
              background: '#2b2d31', border: '1px solid #35363c', borderRadius: 8, padding: '6px 10px',
              display: 'flex', alignItems: 'center', gap: 8, fontSize: 13, color: '#dbdee1'
            }}>
              {f.url.match(/\.(jpg|jpeg|png|gif|webp)$/i)
                ? <img src={f.url} alt="" style={{ height: 40, borderRadius: 4 }} />
                : <span>📎 {f.name}</span>}
              <button onClick={() => setPendingFiles(files => files.filter((_, j) => j !== i))}
                style={{ background: 'none', border: 'none', color: '#f23f42', cursor: 'pointer', fontSize: 16, lineHeight: 1 }}>×</button>
            </div>
          ))}
        </div>
      )}

      <div style={{
        background: '#383a40', borderRadius: 8, display: 'flex', alignItems: 'flex-end',
        padding: '0 16px', gap: 12, border: '1px solid transparent'
      }}>
        {/* File upload */}
        <label style={{ cursor: 'pointer', color: '#80848e', padding: '12px 0', flexShrink: 0, display: 'flex', alignItems: 'center' }}
          onMouseEnter={e => e.currentTarget.style.color = '#dbdee1'}
          onMouseLeave={e => e.currentTarget.style.color = '#80848e'}>
          {uploading ? '⏳' : '+'}
          <input type="file" hidden onChange={handleFileChange} />
        </label>

        <textarea
          ref={textareaRef}
          value={content}
          onChange={handleChange}
          onKeyDown={handleKeyDown}
          placeholder={`Message #${channelName}`}
          rows={1}
          style={{
            flex: 1, background: 'transparent', border: 'none', outline: 'none', resize: 'none',
            color: '#dbdee1', fontSize: 15, lineHeight: 1.5, padding: '11px 0', fontFamily: 'inherit',
            maxHeight: 200, overflowY: 'auto'
          }}
        />

        {/* Emoji button */}
        <button style={{ background: 'none', border: 'none', color: '#80848e', cursor: 'pointer', padding: '12px 0', fontSize: 20, flexShrink: 0 }}
          onMouseEnter={e => e.currentTarget.style.color = '#dbdee1'}
          onMouseLeave={e => e.currentTarget.style.color = '#80848e'}>
          😊
        </button>

        {/* Send */}
        {(content.trim() || pendingFiles.length > 0) && (
          <button onClick={send} style={{
            background: '#5865f2', border: 'none', borderRadius: 4, color: '#fff', cursor: 'pointer',
            padding: '6px 10px', fontSize: 18, flexShrink: 0, marginBottom: 8
          }}>
            ➤
          </button>
        )}
      </div>
    </div>
  );
}
