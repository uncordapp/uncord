import React, { useState } from 'react';
import { useStore } from '../../store';
import api, { getSocket } from '../../utils/api';
import { formatDistanceToNow, format } from 'date-fns';

const BADGES = {
  admin: { label: 'Admin', color: '#f23f42', icon: '🛡️' },
  official: { label: 'Official', color: '#5865f2', icon: '✅' },
  staff: { label: 'Staff', color: '#5865f2', icon: '⚒️' },
  verified: { label: 'Verified', color: '#5865f2', icon: '☑️' },
  nitro: { label: 'Nitro', color: '#ff73fa', icon: '✦' },
  partner: { label: 'Partner', color: '#7289da', icon: '🤝' },
  mod: { label: 'Moderator', color: '#f0b232', icon: '🔨' },
  bot: { label: 'Bot', color: '#5865f2', icon: '🤖' },
  early: { label: 'Early Supporter', color: '#ff73fa', icon: '🌟' },
  dev: { label: 'Developer', color: '#23a559', icon: '💻' },
};

function formatTime(ts) {
  const d = new Date(ts * 1000);
  const now = new Date();
  const diff = now - d;
  if (diff < 86400000) return format(d, 'h:mm a');
  if (diff < 604800000) return format(d, 'EEE h:mm a');
  return format(d, 'MM/dd/yyyy h:mm a');
}

function isGrouped(msg, prev) {
  if (!prev) return false;
  if (msg.author?.id !== prev.author?.id) return false;
  return (msg.created_at - prev.created_at) < 420;
}

export default function MessageItem({ message: msg, prevMessage }) {
  const { user } = useStore();
  const [editing, setEditing] = useState(false);
  const [editContent, setEditContent] = useState(msg.content);
  const [hovered, setHovered] = useState(false);
  const grouped = isGrouped(msg, prevMessage);
  const socket = getSocket();

  const canDelete = user?.id === msg.author_id || user?.role === 'admin';
  const canEdit = user?.id === msg.author_id;

  const saveEdit = () => {
    if (!editContent.trim() || editContent === msg.content) { setEditing(false); return; }
    if (socket) socket.emit('message:edit', { message_id: msg.id, content: editContent });
    setEditing(false);
  };

  const deleteMsg = () => {
    if (socket) socket.emit('message:delete', { message_id: msg.id });
  };

  const react = (emoji) => {
    if (socket) socket.emit('message:react', { message_id: msg.id, emoji });
  };

  const author = msg.author;
  const badges = author?.badges || [];
  const isAdmin = author?.platform_role === 'admin' || author?.role === 'admin';

  return (
    <div
      onMouseEnter={() => setHovered(true)}
      onMouseLeave={() => setHovered(false)}
      style={{
        display: 'flex', gap: 16, padding: grouped ? '1px 16px 1px 72px' : '8px 16px',
        background: hovered ? 'rgba(255,255,255,0.02)' : 'transparent',
        position: 'relative', transition: 'background 0.05s'
      }}
    >
      {/* Avatar */}
      {!grouped ? (
        <div style={{ width: 40, height: 40, borderRadius: '50%', flexShrink: 0, background: author?.accent_color || '#5865f2', display: 'flex', alignItems: 'center', justifyContent: 'center', fontWeight: 700, color: '#fff', fontSize: 16, overflow: 'hidden', cursor: 'pointer', marginTop: 2 }}>
          {author?.avatar
            ? <img src={author.avatar} alt="" style={{ width: '100%', height: '100%', objectFit: 'cover' }} />
            : (author?.username?.[0] || '?').toUpperCase()}
        </div>
      ) : null}

      <div style={{ flex: 1, minWidth: 0 }}>
        {/* Header */}
        {!grouped && (
          <div style={{ display: 'flex', alignItems: 'baseline', gap: 8, marginBottom: 4, flexWrap: 'wrap' }}>
            <span style={{ fontWeight: 600, color: isAdmin ? '#f23f42' : '#f2f3f5', fontSize: 15, cursor: 'pointer' }}>
              {author?.username || 'Unknown'}
            </span>

            {/* Badges */}
            {badges.map(b => BADGES[b] && (
              <span key={b} title={BADGES[b].label} style={{ fontSize: 13, color: BADGES[b].color }}>{BADGES[b].icon}</span>
            ))}
            {isAdmin && !badges.includes('admin') && (
              <span title="Admin" style={{ fontSize: 10, background: '#f23f42', color: '#fff', borderRadius: 3, padding: '1px 4px', fontWeight: 700 }}>ADMIN</span>
            )}
            {author?.nitro === 1 && (
              <span title="Nitro" style={{ fontSize: 10, background: 'linear-gradient(135deg,#ff73fa,#7289da)', color: '#fff', borderRadius: 3, padding: '1px 4px', fontWeight: 700 }}>NITRO</span>
            )}

            <span style={{ fontSize: 12, color: '#4e5058', cursor: 'default' }} title={format(new Date(msg.created_at * 1000), 'PPpp')}>
              {formatTime(msg.created_at)}
            </span>
            {msg.edited_at && <span style={{ fontSize: 10, color: '#4e5058' }}>(edited)</span>}
          </div>
        )}

        {/* Content */}
        {editing ? (
          <div>
            <textarea
              value={editContent}
              onChange={e => setEditContent(e.target.value)}
              onKeyDown={e => {
                if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); saveEdit(); }
                if (e.key === 'Escape') { setEditing(false); setEditContent(msg.content); }
              }}
              autoFocus
              style={{
                width: '100%', background: '#383a40', border: '1px solid #5865f2', borderRadius: 8,
                padding: '10px 12px', color: '#dbdee1', fontSize: 15, resize: 'none', outline: 'none',
                fontFamily: 'inherit', minHeight: 60
              }}
            />
            <div style={{ fontSize: 12, color: '#80848e', marginTop: 4 }}>
              Esc to <span style={{ color: '#f23f42', cursor: 'pointer' }} onClick={() => { setEditing(false); setEditContent(msg.content); }}>cancel</span> • Enter to <span style={{ color: '#5865f2', cursor: 'pointer' }} onClick={saveEdit}>save</span>
            </div>
          </div>
        ) : (
          <div style={{ fontSize: 15, color: '#dbdee1', lineHeight: 1.375, wordBreak: 'break-word', whiteSpace: 'pre-wrap' }}>
            {msg.content}
          </div>
        )}

        {/* Attachments */}
        {msg.attachments?.map((att, i) => (
          <div key={i} style={{ marginTop: 8 }}>
            {att.url?.match(/\.(jpg|jpeg|png|gif|webp)$/i) ? (
              <img src={att.url} alt="" style={{ maxWidth: 400, maxHeight: 300, borderRadius: 4, cursor: 'pointer' }} />
            ) : (
              <a href={att.url} target="_blank" rel="noreferrer" style={{ color: '#00a8fc', fontSize: 14 }}>📎 {att.name || 'Attachment'}</a>
            )}
          </div>
        ))}

        {/* Reactions */}
        {Object.keys(msg.reactions || {}).length > 0 && (
          <div style={{ display: 'flex', flexWrap: 'wrap', gap: 4, marginTop: 4 }}>
            {Object.entries(msg.reactions).map(([emoji, users]) => (
              <button key={emoji} onClick={() => react(emoji)} style={{
                display: 'flex', alignItems: 'center', gap: 4, padding: '2px 6px',
                background: users.includes(user?.id) ? 'rgba(88,101,242,0.3)' : 'rgba(255,255,255,0.06)',
                border: users.includes(user?.id) ? '1px solid rgba(88,101,242,0.6)' : '1px solid rgba(255,255,255,0.1)',
                borderRadius: 12, cursor: 'pointer', color: '#dbdee1', fontSize: 14
              }}>
                <span>{emoji}</span>
                <span style={{ fontSize: 12, fontWeight: 600 }}>{users.length}</span>
              </button>
            ))}
          </div>
        )}
      </div>

      {/* Action toolbar */}
      {hovered && !editing && (
        <div style={{
          position: 'absolute', right: 16, top: -16, background: '#111214', border: '1px solid #35363c',
          borderRadius: 6, display: 'flex', overflow: 'hidden', boxShadow: '0 4px 12px rgba(0,0,0,0.4)', zIndex: 10
        }}>
          {['😀', '👍', '❤️', '😂', '🎉'].map(e => (
            <ActionBtn key={e} onClick={() => react(e)}>{e}</ActionBtn>
          ))}
          {canEdit && <ActionBtn onClick={() => setEditing(true)}>✏️</ActionBtn>}
          {canDelete && <ActionBtn onClick={deleteMsg} danger>🗑️</ActionBtn>}
        </div>
      )}
    </div>
  );
}

function ActionBtn({ children, onClick, danger }) {
  return (
    <button onClick={onClick} style={{
      padding: '6px 10px', background: 'transparent', border: 'none', cursor: 'pointer',
      fontSize: 16, lineHeight: 1, transition: 'background 0.1s',
      color: danger ? '#f23f42' : undefined
    }}
      onMouseEnter={e => e.currentTarget.style.background = danger ? 'rgba(242,63,66,0.15)' : 'rgba(255,255,255,0.06)'}
      onMouseLeave={e => e.currentTarget.style.background = 'transparent'}
    >{children}</button>
  );
}
